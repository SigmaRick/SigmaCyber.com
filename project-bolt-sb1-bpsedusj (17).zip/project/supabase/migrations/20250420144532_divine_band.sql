/*
  # Update Logo URL

  1. Changes
    - Update logo URL to a more permanent, publicly accessible URL
    - Ensures URL is accessible without authentication
    - Uses direct image URL format

  2. Security
    - No security changes needed as settings table already has appropriate RLS
*/

DO $$ 
BEGIN
  IF EXISTS (
    SELECT 1 FROM settings WHERE key = 'logo_url'
  ) THEN
    UPDATE settings 
    SET value = 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&q=80&w=256'
    WHERE key = 'logo_url';
  ELSE
    INSERT INTO settings (key, value)
    VALUES ('logo_url', 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&q=80&w=256');
  END IF;
END $$;