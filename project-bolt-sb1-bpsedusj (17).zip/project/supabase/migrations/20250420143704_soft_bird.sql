/*
  # Update Logo URL

  1. Changes
    - Update the logo_url setting to point to the new logo image
*/

DO $$ 
BEGIN
  IF EXISTS (
    SELECT 1 FROM settings WHERE key = 'logo_url'
  ) THEN
    UPDATE settings 
    SET value = 'https://sigmacybercorp.com/logo.png'
    WHERE key = 'logo_url';
  ELSE
    INSERT INTO settings (key, value)
    VALUES ('logo_url', 'https://sigmacybercorp.com/logo.png');
  END IF;
END $$;