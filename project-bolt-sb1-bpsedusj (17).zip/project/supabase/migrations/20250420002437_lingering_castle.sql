/*
  # Content Management System

  1. New Tables
    - `content_blocks`
      - `id` (uuid, primary key)
      - `key` (text, unique) - Identifier for the content block
      - `title` (text) - Display title
      - `content` (text) - HTML/Markdown content
      - `image_url` (text) - Optional image URL
      - `page` (text) - Page identifier
      - `section` (text) - Section identifier
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS
    - Add policies for admin access
    - Add policies for public read access
*/

CREATE TABLE IF NOT EXISTS content_blocks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text UNIQUE NOT NULL,
  title text NOT NULL,
  content text,
  image_url text,
  page text NOT NULL,
  section text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE content_blocks ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Anyone can view content"
  ON content_blocks
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage content"
  ON content_blocks
  FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM users WHERE id = auth.uid() AND role = 'admin'
  ));

-- Create trigger for updated_at
CREATE TRIGGER update_content_blocks_updated_at
  BEFORE UPDATE ON content_blocks
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();