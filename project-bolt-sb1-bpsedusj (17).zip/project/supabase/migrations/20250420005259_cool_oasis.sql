/*
  # Add Default Content Blocks

  1. New Content
    - Add default content blocks for homepage sections
    - Add default content for other key pages
    
  2. Content Structure
    - Each block has a unique key for easy reference
    - Content is organized by page and section
*/

-- Insert homepage hero content
INSERT INTO content_blocks (key, title, content, page, section)
VALUES 
  ('home_hero_title', 'Hero Title', 'Expert IT Training & Support', 'home', 'hero'),
  ('home_hero_subtitle', 'Hero Subtitle', 'Comprehensive certification programs and enterprise-grade IT solutions for modern businesses.', 'home', 'hero'),
  ('home_certifications_title', 'Certifications Title', 'Professional Certifications', 'home', 'certifications'),
  ('home_certifications_subtitle', 'Certifications Subtitle', 'Expert preparation for networking, security, and information systems auditing certifications', 'home', 'certifications'),
  ('home_ai_title', 'AI Training Title', 'AI Development Training', 'home', 'ai_training'),
  ('home_ai_subtitle', 'AI Training Subtitle', 'Master AI development with hands-on training from industry experts', 'home', 'ai_training'),
  ('home_support_title', 'Support Title', 'Professional IT Support Services', 'home', 'support'),
  ('home_support_subtitle', 'Support Subtitle', 'Enterprise-grade IT support and consulting for businesses of all sizes', 'home', 'support');

-- Insert about section content
INSERT INTO content_blocks (key, title, content, page, section)
VALUES
  ('about_intro_title', 'About Title', 'About Sigma Cyber', 'about', 'intro'),
  ('about_intro_content', 'About Content', 'We are a leading provider of IT certification training and professional support services. Our expert instructors and comprehensive programs help professionals advance their careers and organizations strengthen their infrastructure.', 'about', 'intro');

-- Insert contact information
INSERT INTO content_blocks (key, title, content, page, section)
VALUES
  ('contact_address', 'Office Address', '710 7th Street Clanton, AL 35045', 'contact', 'info'),
  ('contact_phone', 'Phone Number', '205.415.9470', 'contact', 'info'),
  ('contact_email', 'Email Address', 'cyberexperts@sigmacybercorp.com', 'contact', 'info');