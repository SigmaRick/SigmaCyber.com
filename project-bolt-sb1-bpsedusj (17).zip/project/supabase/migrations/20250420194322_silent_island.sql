/*
  # Update Logo URL and Add Error Handling

  1. Changes
    - Update logo URL in settings table
    - Ensure URL is properly encoded
*/

DO $$ 
BEGIN
  UPDATE settings 
  SET value = 'https://wkddnyxqlsewacuexjyi.supabase.co/storage/v1/object/public/images/small%20logo.jpg'
  WHERE key = 'logo_url';
END $$;