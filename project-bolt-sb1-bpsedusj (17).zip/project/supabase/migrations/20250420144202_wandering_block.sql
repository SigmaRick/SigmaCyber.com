/*
  # Update Logo URL

  1. Changes
    - Updates the logo_url setting with the new Facebook image URL
    - Uses safe upsert pattern to handle both update and insert cases
*/

DO $$ 
BEGIN
  IF EXISTS (
    SELECT 1 FROM settings WHERE key = 'logo_url'
  ) THEN
    UPDATE settings 
    SET value = 'https://scontent-atl3-1.xx.fbcdn.net/v/t39.30808-1/492013428_10232580397204692_4513410046641760826_n.jpg?stp=c128.0.1024.1024a_dst-jpg_s480x480_tt6&_nc_cat=110&ccb=1-7&_nc_sid=2d3e12&_nc_ohc=BqYAa9Ie9I8Q7kNvwHVsfV4&_nc_oc=Adm8tgRssRxx9ECjWg95gg9X3Udv30978ccmQ7GuksHzd_zCLgvHX3nQVy-3i-zNlPI&_nc_zt=24&_nc_ht=scontent-atl3-1.xx&_nc_gid=Rb4dahTX9QZvqSxxgLfS-g&oh=00_AfFmGaUG79txTQNzryy5g8cWrx_xRgLOxFGCz_k9gUt9hA&oe=680A4F48'
    WHERE key = 'logo_url';
  ELSE
    INSERT INTO settings (key, value)
    VALUES ('logo_url', 'https://scontent-atl3-1.xx.fbcdn.net/v/t39.30808-1/492013428_10232580397204692_4513410046641760826_n.jpg?stp=c128.0.1024.1024a_dst-jpg_s480x480_tt6&_nc_cat=110&ccb=1-7&_nc_sid=2d3e12&_nc_ohc=BqYAa9Ie9I8Q7kNvwHVsfV4&_nc_oc=Adm8tgRssRxx9ECjWg95gg9X3Udv30978ccmQ7GuksHzd_zCLgvHX3nQVy-3i-zNlPI&_nc_zt=24&_nc_ht=scontent-atl3-1.xx&_nc_gid=Rb4dahTX9QZvqSxxgLfS-g&oh=00_AfFmGaUG79txTQNzryy5g8cWrx_xRgLOxFGCz_k9gUt9hA&oe=680A4F48');
  END IF;
END $$;