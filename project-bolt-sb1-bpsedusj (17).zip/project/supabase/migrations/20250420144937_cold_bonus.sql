/*
  # Set up Storage for Images
  
  1. Changes
    - Create public bucket for storing images
    - Add storage policies for admin access
    - Add public read access policy
*/

-- Create public bucket for images
INSERT INTO storage.buckets (id, name, public)
VALUES ('images', 'images', true);

-- Allow public access to read images
CREATE POLICY "Public Access"
ON storage.objects FOR SELECT
TO public
USING (bucket_id = 'images');

-- Allow authenticated users to upload images
CREATE POLICY "Authenticated users can upload images"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'images');

-- Allow admins to manage all images
CREATE POLICY "Admins can manage images" 
ON storage.objects FOR ALL 
TO authenticated
USING (
  bucket_id = 'images' AND
  (
    SELECT public.users.role = 'admin'
    FROM auth.users AS au
    JOIN public.users ON public.users.id = au.id
    WHERE au.id = auth.uid()
  )
);