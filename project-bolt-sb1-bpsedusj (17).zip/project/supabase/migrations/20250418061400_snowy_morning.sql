/*
  # Create Admin User

  1. Changes
    - Insert admin user with credentials:
      - Email: admin@sigmacybercorp.com
      - Role: admin
      - First Name: Admin
      - Last Name: User

  2. Security
    - Uses secure UUID generation for ID
    - Sets admin role with full access
*/

INSERT INTO users (
  email,
  first_name,
  last_name,
  role
) VALUES (
  'admin@sigmacybercorp.com',
  'Admin',
  'User',
  'admin'
);