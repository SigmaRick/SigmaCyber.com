/*
  # Update Logo URL

  1. Changes
    - Update logo_url setting to use new small logo image
*/

DO $$ 
BEGIN
  IF EXISTS (
    SELECT 1 FROM settings WHERE key = 'logo_url'
  ) THEN
    UPDATE settings 
    SET value = 'https://wkddnyxqlsewacuexjyi.supabase.co/storage/v1/object/public/images//small%20logo.jpg'
    WHERE key = 'logo_url';
  ELSE
    INSERT INTO settings (key, value)
    VALUES ('logo_url', 'https://wkddnyxqlsewacuexjyi.supabase.co/storage/v1/object/public/images//small%20logo.jpg');
  END IF;
END $$;