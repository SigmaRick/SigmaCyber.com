/*
  # Update Logo URL to use Supabase Storage
  
  1. Changes
    - Update logo_url setting to use new Supabase storage URL
*/

DO $$ 
BEGIN
  IF EXISTS (
    SELECT 1 FROM settings WHERE key = 'logo_url'
  ) THEN
    UPDATE settings 
    SET value = 'https://wkddnyxqlsewacuexjyi.supabase.co/storage/v1/object/public/images//FullLogo.jpg'
    WHERE key = 'logo_url';
  ELSE
    INSERT INTO settings (key, value)
    VALUES ('logo_url', 'https://wkddnyxqlsewacuexjyi.supabase.co/storage/v1/object/public/images//FullLogo.jpg');
  END IF;
END $$;