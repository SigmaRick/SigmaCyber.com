/*
  # Update Logo URL
  
  1. Changes
    - Update logo URL in settings table with properly encoded URL
*/

DO $$ 
BEGIN
  UPDATE settings 
  SET value = 'https://wkddnyxqlsewacuexjyi.supabase.co/storage/v1/object/public/images//small%20logo.jpg'
  WHERE key = 'logo_url';
END $$;