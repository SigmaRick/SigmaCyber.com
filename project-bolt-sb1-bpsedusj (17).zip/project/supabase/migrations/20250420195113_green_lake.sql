DO $$ 
BEGIN
  UPDATE settings 
  SET value = 'https://wkddnyxqlsewacuexjyi.supabase.co/storage/v1/object/public/images//FullLogo.jpg'
  WHERE key = 'logo_url';
END $$;