/*
  # Add Testimonials Table

  1. New Tables
    - `testimonials`
      - `id` (uuid, primary key)
      - `name` (text) - Name of the person giving testimonial
      - `company` (text) - Company or organization
      - `position` (text) - Job title or position
      - `content` (text) - Testimonial content
      - `rating` (integer) - Rating from 1-5
      - `image_url` (text) - Optional profile image URL
      - `is_featured` (boolean) - Whether to feature on homepage
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS
    - Add policies for admin access
    - Add policies for public read access
*/

CREATE TABLE IF NOT EXISTS testimonials (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  company text,
  position text,
  content text NOT NULL,
  rating integer NOT NULL CHECK (rating >= 1 AND rating <= 5),
  image_url text,
  is_featured boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE testimonials ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Anyone can view testimonials"
  ON testimonials
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage testimonials"
  ON testimonials
  FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM users WHERE id = auth.uid() AND role = 'admin'
  ));

-- Create trigger for updated_at
CREATE TRIGGER update_testimonials_updated_at
  BEFORE UPDATE ON testimonials
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();

-- Insert sample testimonials
INSERT INTO testimonials (name, company, position, content, rating, is_featured)
VALUES 
  ('John Smith', 'TechCorp Inc.', 'CIO', 'The CCNP Enterprise training was exceptional. The hands-on labs and expert instruction prepared me perfectly for the certification exam.', 5, true),
  ('Sarah Johnson', 'SecureNet Solutions', 'Security Analyst', 'The Security+ course provided exactly what I needed to advance my cybersecurity career. Highly recommended!', 5, true),
  ('Michael Chen', 'Global Financial Services', 'Network Engineer', 'The Fortinet NSE 7 training was comprehensive and practical. I use the knowledge gained every day in my work.', 4, true);