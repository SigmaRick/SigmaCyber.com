import React from 'react';
import { Routes, Route, Link } from 'react-router-dom';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import { Users, BarChart, MapPin, Phone, Mail, ChevronRight, Lock, Code, Brain, Award, Network, CheckCircle, Shield, Bot, Sparkles } from 'lucide-react';
import { useEffect, useState, useCallback } from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import ContactForm from './components/ContactForm';
import CertificationTraining from './pages/CertificationTraining';
import ITSupport from './pages/ITSupport';
import CCNACertification from './pages/certifications/CCNA';
import TrainingPortal from './pages/TrainingPortal';
import CCNPEnterpriseCertification from './pages/certifications/CCNPEnterprise';
import CiscoCyberAssociateCertification from './pages/certifications/CiscoCyberAssociate';
import CiscoCyberProfessionalCertification from './pages/certifications/CiscoCyberProfessional';
import NetworkInfrastructure from './pages/services/NetworkInfrastructure';
import CloudServices from './pages/services/CloudServices';
import ManagedServices from './pages/services/ManagedServices';
import EnterpriseCybersecurity from './pages/services/EnterpriseCybersecurity';
import DataManagement from './pages/services/DataManagement';
import EndUserSupport from './pages/services/EndUserSupport';
import TermsOfUse from './pages/TermsOfUse';
import PrivacyPolicy from './pages/PrivacyPolicy';
import Instructor from './pages/Instructor';
import AITraining from './pages/AITraining';
import CompTIASecurityPlusCertification from './pages/certifications/CompTIASecurityPlus';
import FortinetNSE4Certification from './pages/certifications/FortinetNSE4';
import FortinetNSE7Certification from './pages/certifications/FortinetNSE7';
import CISACertification from './pages/certifications/CISA';
import Registration from './pages/Registration';
import PortalDashboard from './pages/PortalDashboard';
import AdminDashboard from './pages/AdminDashboard';
import AdminUsers from './pages/AdminUsers';
import AdminCourses from './pages/AdminCourses';
import AdminSettings from './pages/AdminSettings';
import AdminContent from './pages/AdminContent';
import AIFundamentals from './pages/ai-training/Fundamentals';
import AIAdvanced from './pages/ai-training/Advanced';
import AIEnterprise from './pages/ai-training/Enterprise';
import AdminLogin from './pages/AdminLogin';
import SigmaAI from './pages/SigmaAI';
import AdminRoute from './components/AdminRoute';
import Cybersecurity from './pages/Cybersecurity';

function HomePage() {
  return (
    <div className="min-h-screen bg-white dark:bg-gray-900">
      <Header />
      <div className="relative">
        <Slider
          dots={true}
          infinite={true}
          speed={1000}
          slidesToShow={1}
          slidesToScroll={1}
          autoplay={true}
          autoplaySpeed={5000}
          className="hero-slider"
        >
          <div>
            <div className="relative">
              <img
                src="https://wkddnyxqlsewacuexjyi.supabase.co/storage/v1/object/public/images//Enterprise-Cybersecurity.webp"
                alt="Enterprise cybersecurity operations"
                className="w-full h-[600px] object-cover"
              />
              <div className="absolute inset-0 bg-gray-900/70" />
              <div className="absolute inset-0 flex items-center">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                  <div className="max-w-3xl relative z-20 px-12 sm:px-0">
                    <h2 className="text-5xl lg:text-6xl font-bold text-white mb-6">Enterprise Cybersecurity</h2>
                    <p className="text-2xl lg:text-3xl text-gray-300">Advanced threat protection and 24/7 security monitoring for your business infrastructure.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div>
            <div className="relative">
              <img
                src="https://wkddnyxqlsewacuexjyi.supabase.co/storage/v1/object/public/images//1565128469489.jfif"
                alt="AI-powered website development"
                className="w-full h-[600px] object-cover"
              />
              <div className="absolute inset-0 bg-gray-900/70" />
              <div className="absolute inset-0 flex items-center">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                  <div className="max-w-3xl relative z-20 px-12 sm:px-0">
                    <h2 className="text-5xl lg:text-6xl font-bold text-white mb-6">Sigma AI Solutions</h2>
                    <p className="text-2xl lg:text-3xl text-gray-300">Building intelligent websites and applications powered by advanced AI technology.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div>
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&q=80&w=1920"
                alt="Modern data center with server racks"
                className="w-full h-[600px] object-cover"
              />
              <div className="absolute inset-0 bg-gray-900/70" />
              <div className="absolute inset-0 flex items-center">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                  <div className="max-w-3xl relative z-20 px-12 sm:px-0">
                    <h2 className="text-5xl lg:text-6xl font-bold text-white mb-6">Expert IT Training & Support</h2>
                    <p className="text-2xl lg:text-3xl text-gray-300">Comprehensive certification programs and enterprise-grade IT solutions for modern businesses.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div>
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1620712943543-bcc4688e7485?auto=format&fit=crop&q=80&w=1920"
                alt="AI development and machine learning"
                className="w-full h-[600px] object-cover"
              />
              <div className="absolute inset-0 bg-gray-900/70" />
              <div className="absolute inset-0 flex items-center">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                  <div className="max-w-3xl relative z-20 px-12 sm:px-0">
                    <h2 className="text-5xl lg:text-6xl font-bold text-white mb-6">Master AI Development</h2>
                    <p className="text-2xl lg:text-3xl text-gray-300">Learn to build powerful AI applications with hands-on training from industry experts.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div>
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=1920"
                alt="Network security operations center"
                className="w-full h-[600px] object-cover"
              />
              <div className="absolute inset-0 bg-gray-900/70" />
              <div className="absolute inset-0 flex items-center">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                  <div className="max-w-3xl relative z-20 px-12 sm:px-0">
                    <h2 className="text-5xl lg:text-6xl font-bold text-white mb-6">Advanced Security Training</h2>
                    <p className="text-2xl lg:text-3xl text-gray-300">Master cybersecurity with industry-recognized certifications from Cisco, Fortinet, and CompTIA.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div>
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1614064641938-3bbee52942c7?auto=format&fit=crop&q=80&w=1920"
                alt="Cybersecurity professional at work"
                className="w-full h-[600px] object-cover"
              />
              <div className="absolute inset-0 bg-gray-900/70" />
              <div className="absolute inset-0 flex items-center">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                  <div className="max-w-3xl relative z-20 px-12 sm:px-0">
                    <h2 className="text-5xl lg:text-6xl font-bold text-white mb-6">Professional IT Support</h2>
                    <p className="text-2xl lg:text-3xl text-gray-300">24/7 enterprise-grade technical support and infrastructure management services.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Slider>
        
        <div className="absolute inset-0 z-10 flex items-center pointer-events-none">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl relative z-20 hidden">
              <h1 className="text-4xl font-bold tracking-tight text-white sm:text-5xl lg:text-6xl">
                Expert IT Training & Professional Support Services
              </h1>
              <p className="mt-6 text-xl text-gray-300 max-w-2xl">
                Comprehensive IT solutions including professional certification training and enterprise-grade technical support. Elevate your career or strengthen your business infrastructure.
              </p>
              <div className="mt-10 space-x-4">
                <Link
                  to="/certification-training"
                  className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 transition-colors pointer-events-auto"
                >
                  Certification Training
                  <ChevronRight className="ml-2 h-5 w-5" />
                </Link>
                <Link
                  to="/it-support"
                  className="inline-flex items-center px-6 py-3 border-2 border-white text-base font-medium rounded-md text-white hover:bg-white hover:text-gray-900 transition-colors pointer-events-auto"
                >
                  IT Support
                  <ChevronRight className="ml-2 h-5 w-5" />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Sigma AI Section */}
      <div className="py-24 bg-gradient-to-r from-blue-900 to-blue-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-white mb-6">Sigma AI Solutions</h2>
              <p className="text-xl text-blue-100 mb-8">
                Transform your business with our AI-powered website solutions. From intelligent chatbots to dynamic content generation, we build websites that think and adapt.
              </p>
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="p-2 bg-blue-800 rounded-lg">
                    <Bot className="h-6 w-6 text-blue-200" />
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-white">24/7 AI Chat Support</h4>
                    <p className="text-blue-100">Intelligent customer service that never sleeps</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="p-2 bg-blue-800 rounded-lg">
                    <Brain className="h-6 w-6 text-blue-200" />
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-white">Smart Content Generation</h4>
                    <p className="text-blue-100">AI-powered content that engages your audience</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="p-2 bg-blue-800 rounded-lg">
                    <Sparkles className="h-6 w-6 text-blue-200" />
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-white">Dynamic Personalization</h4>
                    <p className="text-blue-100">Websites that adapt to each visitor</p>
                  </div>
                </div>
              </div>
              <div className="mt-8">
                <Link
                  to="/sigma-ai"
                  className="inline-flex items-center px-6 py-3 border-2 border-white text-base font-medium rounded-md text-white hover:bg-white hover:text-blue-900 transition-colors"
                >
                  Learn More About Sigma AI
                  <ChevronRight className="ml-2 h-5 w-5" />
                </Link>
              </div>
            </div>
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1488229297570-58520851e868?auto=format&fit=crop&q=80"
                alt="AI-powered solutions"
                className="rounded-xl shadow-2xl"
              />
              <div className="absolute -bottom-6 -right-6 bg-white text-blue-900 p-6 rounded-xl shadow-xl">
                <p className="text-2xl font-bold">100%</p>
                <p className="text-sm">AI-Powered</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Cybersecurity Section */}
      <div className="py-24 bg-gradient-to-r from-gray-900 to-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-white mb-6">Enterprise Cybersecurity</h2>
              <p className="text-xl text-gray-300 mb-8">
                Protect your business with advanced threat detection, 24/7 monitoring, and expert security architecture. Our comprehensive security solutions safeguard your digital assets.
              </p>
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="p-2 bg-gray-800 rounded-lg">
                    <Shield className="h-6 w-6 text-blue-400" />
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-white">Advanced Threat Protection</h4>
                    <p className="text-gray-300">Next-generation firewall and intrusion prevention systems</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="p-2 bg-gray-800 rounded-lg">
                    <Lock className="h-6 w-6 text-blue-400" />
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-white">24/7 Security Monitoring</h4>
                    <p className="text-gray-300">Round-the-clock threat detection and incident response</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="p-2 bg-gray-800 rounded-lg">
                    <Bot className="h-6 w-6 text-blue-400" />
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-white">AI-Powered Security</h4>
                    <p className="text-gray-300">Machine learning for predictive threat detection</p>
                  </div>
                </div>
              </div>
              <div className="mt-8">
                <Link
                  to="/cybersecurity"
                  className="inline-flex items-center px-6 py-3 border-2 border-white text-base font-medium rounded-md text-white hover:bg-white hover:text-gray-900 transition-colors"
                >
                  Learn More About Security Solutions
                  <ChevronRight className="ml-2 h-5 w-5" />
                </Link>
              </div>
            </div>
            <div className="relative">
              <div className="bg-white p-8 rounded-xl">
              <img
                src="https://wkddnyxqlsewacuexjyi.supabase.co/storage/v1/object/public/images//logo-engage-partner-program-advocate-integrator.png"
                alt="Fortinet Partner Logo"
                className="rounded-xl shadow-2xl"
              />
              </div>
              <div className="absolute -bottom-6 -right-6 bg-blue-600 text-white p-6 rounded-xl shadow-xl">
                <p className="text-2xl font-bold">24/7</p>
                <p className="text-sm">Protection</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Certifications Section */}
      <div id="certifications" className="py-24 bg-gray-50 dark:bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-16 relative">
            <Link to="/instructor" className="block bg-gradient-to-r from-blue-900 to-blue-700 rounded-xl overflow-hidden shadow-xl hover:opacity-95 transition-opacity">
              <div className="px-8 py-10 sm:px-10 relative z-10">
                <div className="flex flex-col sm:flex-row items-center gap-8">
                  <div className="w-48 h-48 rounded-full overflow-hidden flex-shrink-0 border-4 border-white shadow-lg">
                    <img
                      src="https://wkddnyxqlsewacuexjyi.supabase.co/storage/v1/object/public/images//Untitledrrrr.png"
                      alt="Rick Miller - Trusted Advisor"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="text-center sm:text-left">
                    <h3 className="text-2xl font-bold text-white mb-2">Meet Your Trusted Advisor - Rick Miller</h3>
                    <p className="text-blue-100 text-lg mb-4">
                      With over 25 years of hands-on experience in enterprise IT and cybersecurity, Rick brings unparalleled expertise from working with Fortune 500 companies, government agencies, and critical infrastructure. His extensive experience includes successfully deploying and managing large-scale Bitcoin mining operations with over 10,000 miners, implementing advanced AI solutions, and leading complex enterprise infrastructure projects. As a certified expert in Cisco, Fortinet, CompTIA, and ISACA technologies, he combines cutting-edge technical knowledge with real-world implementation experience to deliver exceptional results for both training and enterprise solutions.
                    </p>
                    <div className="flex flex-wrap justify-center sm:justify-start gap-3">
                      <div className="bg-white/10 px-4 py-2 rounded-full text-blue-50">CCNP Enterprise</div>
                      <div className="bg-white/10 px-4 py-2 rounded-full text-blue-50">NSE 7</div>
                      <div className="bg-white/10 px-4 py-2 rounded-full text-blue-50">CISA</div>
                      <div className="bg-white/10 px-4 py-2 rounded-full text-blue-50">Security+</div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="absolute inset-0 bg-gradient-to-r from-blue-600/50 to-blue-800/50" />
            </Link>
          </div>

          <div className="text-center">
            <h2 className="text-3xl font-bold tracking-tight text-gray-900 dark:text-white sm:text-4xl">
              Professional Certifications
            </h2>
            <p className="mt-4 text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              Expert preparation for networking, security, and information systems auditing certifications
            </p>
          </div>

          <div className="mt-16 grid grid-cols-1 gap-8 lg:grid-cols-3">
            {/* Cisco Certifications */}
            <div className="bg-white dark:bg-gray-700 rounded-lg shadow-lg overflow-hidden">
              <div className="relative h-48">
                <img
                  src="https://wkddnyxqlsewacuexjyi.supabase.co/storage/v1/object/public/images//cisco%20switches.jpg"
                  alt="Cisco Networking Equipment"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900/80 to-transparent" />
              </div>
              <div className="px-6 py-8">
                <div className="flex items-center justify-between">
                  <h3 className="text-2xl font-bold text-gray-900 dark:text-white">Cisco Certifications</h3>
                  <Network className="h-8 w-8 text-blue-600" />
                </div>
                <div className="mt-8 space-y-4">
                  <div className="flex items-start">
                    <CheckCircle className="h-6 w-6 text-green-500 mt-1" />
                    <div className="ml-3">
                      <h4 className="text-lg font-medium text-gray-900 dark:text-white">Cisco CCNA</h4>
                      <p className="mt-1 text-gray-500 dark:text-gray-300">Foundation in networking, security, and automation</p>
                      <Link to="/certification-training/ccna" className="inline-block mt-2 text-blue-600 hover:text-blue-700 font-medium">
                        Learn more →
                      </Link>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle className="h-6 w-6 text-green-500 mt-1" />
                    <div className="ml-3">
                      <h4 className="text-lg font-medium text-gray-900 dark:text-white">Cisco CCNP Enterprise</h4>
                      <p className="mt-1 text-gray-500 dark:text-gray-300">Advanced enterprise networking and infrastructure expertise</p>
                      <Link to="/certification-training/ccnp-enterprise" className="inline-block mt-2 text-blue-600 hover:text-blue-700 font-medium">
                        Learn more →
                      </Link>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle className="h-6 w-6 text-green-500 mt-1" />
                    <div className="ml-3">
                      <h4 className="text-lg font-medium text-gray-900 dark:text-white">Cisco Certified Cybersecurity Associate</h4>
                      <p className="mt-1 text-gray-500 dark:text-gray-300">Essential cybersecurity concepts and skills</p>
                      <Link to="/certification-training/cisco-certified-cybersecurity-associate" className="inline-block mt-2 text-blue-600 hover:text-blue-700 font-medium">
                        Learn more →
                      </Link>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle className="h-6 w-6 text-green-500 mt-1" />
                    <div className="ml-3">
                      <h4 className="text-lg font-medium text-gray-900 dark:text-white">Cisco Certified Cybersecurity Professional</h4>
                      <p className="mt-1 text-gray-500 dark:text-gray-300">Advanced enterprise security architecture and threat detection</p>
                      <Link to="/certification-training/cisco-certified-cybersecurity-professional" className="inline-block mt-2 text-blue-600 hover:text-blue-700 font-medium">
                        Learn more →
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            {/* Fortinet Certifications */}
            <div className="bg-white dark:bg-gray-700 rounded-lg shadow-lg overflow-hidden">
              <div className="relative h-48">
                <img
                  src="https://wkddnyxqlsewacuexjyi.supabase.co/storage/v1/object/public/images//firewall.jpg"
                  alt="Network Security Operations"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900/80 to-transparent" />
              </div>
              <div className="px-6 py-8">
                <div className="flex items-center justify-between">
                  <h3 className="text-2xl font-bold text-gray-900 dark:text-white">Fortinet Certifications</h3>
                  <Shield className="h-8 w-8 text-blue-600" />
                </div>
                <div className="mt-8 space-y-4">
                  <div className="flex items-start">
                    <CheckCircle className="h-6 w-6 text-green-500 mt-1" />
                    <div className="ml-3">
                      <h4 className="text-lg font-medium text-gray-900 dark:text-white">NSE 4 - Network Security</h4>
                      <p className="mt-1 text-gray-500 dark:text-gray-300">Network Security Professional certification</p>
                      <Link to="/certification-training/fortinet-nse-4-network-security-professional" className="inline-block mt-2 text-blue-600 hover:text-blue-700 font-medium">
                        Learn more →
                      </Link>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle className="h-6 w-6 text-green-500 mt-1" />
                    <div className="ml-3">
                      <h4 className="text-lg font-medium text-gray-900 dark:text-white">NSE 7 - Network Security</h4>
                      <p className="mt-1 text-gray-500 dark:text-gray-300">Advanced Network Security Professional certification</p>
                      <Link to="/certification-training/fortinet-nse-7-network-security" className="inline-block mt-2 text-blue-600 hover:text-blue-700 font-medium">
                        Learn more →
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            {/* ISACA Certifications */}
            <div className="bg-white dark:bg-gray-700 rounded-lg shadow-lg overflow-hidden">
              <div className="relative h-48">
                <img
                  src="https://wkddnyxqlsewacuexjyi.supabase.co/storage/v1/object/public/images//audit.jpg"
                  alt="IT Audit and Security"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900/80 to-transparent" />
              </div>
              <div className="px-6 py-8">
                <div className="flex items-center justify-between">
                  <h3 className="text-2xl font-bold text-gray-900 dark:text-white">Professional Audit & Security Certifications</h3>
                  <BarChart className="h-8 w-8 text-blue-600" />
                </div>
                <div className="mt-8 space-y-4">
                  <div className="flex items-start">
                    <CheckCircle className="h-6 w-6 text-green-500 mt-1" />
                    <div className="ml-3">
                      <h4 className="text-lg font-medium text-gray-900 dark:text-white">CompTIA Security+</h4>
                      <p className="mt-1 text-gray-500 dark:text-gray-300">Industry-standard certification for cybersecurity professionals</p>
                      <Link to="/certification-training/comptia-security-plus" className="inline-block mt-2 text-blue-600 hover:text-blue-700 font-medium">
                        Learn more →
                      </Link>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle className="h-6 w-6 text-green-500 mt-1" />
                    <div className="ml-3">
                
                      <h4 className="text-lg font-medium text-gray-900 dark:text-white">Certified Information Systems Auditor® (CISA)</h4>
                      <p className="mt-1 text-gray-500 dark:text-gray-300">Global standard for IT audit, control, and security professionals</p>
                      <Link to="/certification-training/isaca-cisa" className="inline-block mt-2 text-blue-600 hover:text-blue-700 font-medium">
                        Learn more →
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* AI Training Section */}
      <div className="py-24 bg-gradient-to-r from-indigo-900 to-indigo-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">
              AI Development Training
            </h2>
            <p className="mt-4 text-lg text-indigo-100 max-w-2xl mx-auto">
              Master AI development with hands-on training from industry experts
            </p>
          </div>

          <div className="mt-16 grid grid-cols-1 gap-8 lg:grid-cols-3">
            <div className="bg-white/10 backdrop-blur-sm rounded-lg shadow-lg overflow-hidden border border-white/10">
              <div className="relative h-48">
                <img
                  src="https://wkddnyxqlsewacuexjyi.supabase.co/storage/v1/object/public/images//ai%20training%20fundamentals.jpg"
                  alt="AI Development Fundamentals"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-indigo-900/80 to-transparent" />
              </div>
              <div className="px-6 py-8">
                <div className="flex items-center justify-between">
                  <h3 className="text-2xl font-bold text-white">AI Fundamentals</h3>
                  <Brain className="h-8 w-8 text-blue-600" />
                </div>
                <div className="mt-8 space-y-4">
                  <div className="flex items-start">
                    <CheckCircle className="h-6 w-6 text-green-500 mt-1" />
                    <div className="ml-3">
                      <h4 className="text-lg font-medium text-white">Introduction to AI Development</h4>
                      <p className="mt-1 text-indigo-200">Learn the basics of AI development with Bolt</p>
                      <Link to="/ai-training/fundamentals" className="inline-block mt-2 text-blue-300 hover:text-blue-200 font-medium">
                        Learn more →
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm rounded-lg shadow-lg overflow-hidden border border-white/10">
              <div className="relative h-48">
                <img
                  src="https://wkddnyxqlsewacuexjyi.supabase.co/storage/v1/object/public/images//ai%20advanced.jpg"
                  alt="Advanced AI Development"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-indigo-900/80 to-transparent" />
              </div>
              <div className="px-6 py-8">
                <div className="flex items-center justify-between">
                  <h3 className="text-2xl font-bold text-white">Advanced AI</h3>
                  <Code className="h-8 w-8 text-blue-600" />
                </div>
                <div className="mt-8 space-y-4">
                  <div className="flex items-start">
                    <CheckCircle className="h-6 w-6 text-green-500 mt-1" />
                    <div className="ml-3">
                      <h4 className="text-lg font-medium text-white">Advanced AI Development</h4>
                      <p className="mt-1 text-indigo-200">Master complex AI application development</p>
                      <Link to="/ai-training/advanced" className="inline-block mt-2 text-blue-300 hover:text-blue-200 font-medium">
                        Learn more →
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm rounded-lg shadow-lg overflow-hidden border border-white/10">
              <div className="relative h-48">
                <img
                  src="https://wkddnyxqlsewacuexjyi.supabase.co/storage/v1/object/public/images//enterprise%20ai.jpg"
                  alt="Enterprise AI Solutions"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-indigo-900/80 to-transparent" />
              </div>
              <div className="px-6 py-8">
                <div className="flex items-center justify-between">
                  <h3 className="text-2xl font-bold text-white">Enterprise AI</h3>
                  <Shield className="h-8 w-8 text-blue-600" />
                </div>
                <div className="mt-8 space-y-4">
                  <div className="flex items-start">
                    <CheckCircle className="h-6 w-6 text-green-500 mt-1" />
                    <div className="ml-3">
                      <h4 className="text-lg font-medium text-white">Enterprise AI Solutions</h4>
                      <p className="mt-1 text-indigo-200">Build production-ready AI applications</p>
                      <Link to="/ai-training/enterprise" className="inline-block mt-2 text-blue-300 hover:text-blue-200 font-medium">
                        Learn more →
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* IT Support Services Section */}
      <div id="support" className="py-24 bg-gradient-to-r from-gray-100 to-gray-50 dark:from-gray-800 dark:to-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold tracking-tight text-gray-900 dark:text-white sm:text-4xl">
              Professional IT Support Services
            </h2>
            <p className="mt-4 text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              Enterprise-grade IT support and consulting for businesses of all sizes
            </p>
          </div>

          <div className="mt-16 grid grid-cols-1 gap-8 lg:grid-cols-3">
            <div className="bg-white dark:bg-gray-700  rounded-lg shadow-lg overflow-hidden">
              <div className="relative h-48">
                <img
                  src="https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&q=80"
                  alt="Network Infrastructure"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900/80 to-transparent" />
              </div>
              <div className="px-6 py-8">
                <div className="flex items-center justify-between">
                  <h3 className="text-2xl font-bold text-gray-900 dark:text-white">Network Infrastructure</h3>
                  <Network className="h-8 w-8 text-blue-600" />
                </div>
                <ul className="mt-8 space-y-4">
                  <li className="flex items-start">
                    <CheckCircle className="h-6 w-6 text-green-500 mt-1 flex-shrink-0" />
                    <span className="ml-3 text-gray-500 dark:text-gray-300">Network design and implementation</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-6 w-6 text-green-500 mt-1 flex-shrink-0" />
                    <span className="ml-3 text-gray-500 dark:text-gray-300">24/7 network monitoring</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-6 w-6 text-green-500 mt-1 flex-shrink-0" />
                    <span className="ml-3 text-gray-500 dark:text-gray-300">Performance optimization</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-6 w-6 text-green-500 mt-1 flex-shrink-0" />
                    <span className="ml-3 text-gray-500 dark:text-gray-300">Any Network Related Issues</span>
                  </li>
                </ul>
              </div>
            </div>
            <div className="bg-white dark:bg-gray-700 rounded-lg shadow-lg overflow-hidden">
              <div className="relative h-48">
                <img
                  src="https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&q=80"
                  alt="Cyber Security Services"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900/80 to-transparent" />
              </div>
              <div className="px-6 py-8">
                <div className="flex items-center justify-between">
                  <h3 className="text-2xl font-bold text-gray-900 dark:text-white">Cyber Security Services</h3>
                  <Shield className="h-8 w-8 text-blue-600" />
                </div>
                <ul className="mt-8 space-y-4">
                  <li className="flex items-start">
                    <CheckCircle className="h-6 w-6 text-green-500 mt-1 flex-shrink-0" />
                    <span className="ml-3 text-gray-500 dark:text-gray-300">Cyber security assessments and audits</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-6 w-6 text-green-500 mt-1 flex-shrink-0" />
                    <span className="ml-3 text-gray-500 dark:text-gray-300">Firewall management</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-6 w-6 text-green-500 mt-1 flex-shrink-0" />
                    <span className="ml-3 text-gray-500 dark:text-gray-300">Incident response</span>
                  </li>
                </ul>
              </div>
            </div>
            <div className="bg-white dark:bg-gray-700 rounded-lg shadow-lg overflow-hidden">
              <div className="relative h-48">
                <img
                  src="https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80"
                  alt="Managed Services"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900/80 to-transparent" />
              </div>
              <div className="px-6 py-8">
                <div className="flex items-center justify-between">
                  <h3 className="text-2xl font-bold text-gray-900 dark:text-white">Managed Services</h3>
                  <Code className="h-8 w-8 text-blue-600" />
                </div>
                <ul className="mt-8 space-y-4">
                  <li className="flex items-start">
                    <CheckCircle className="h-6 w-6 text-green-500 mt-1 flex-shrink-0" />
                    <span className="ml-3 text-gray-500 dark:text-gray-300">Help desk support</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-6 w-6 text-green-500 mt-1 flex-shrink-0" />
                    <span className="ml-3 text-gray-500 dark:text-gray-300">System administration</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-6 w-6 text-green-500 mt-1 flex-shrink-0" />
                    <span className="ml-3 text-gray-500 dark:text-gray-300">Cloud services management</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-24 bg-white dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold tracking-tight text-gray-900 dark:text-white sm:text-4xl">
              Comprehensive Cyber Security Training
            </h2>
          </div>

          <div className="mt-20 grid grid-cols-1 gap-12 sm:grid-cols-2 lg:grid-cols-3">
            <Feature
              icon={Lock}
              title="Security Awareness"
              description="Training aligned with latest networking and information systems audit certifications."
            />
            <Feature
              icon={Award}
              title="Certified Instructors"
              description="Learn from professionals with extensive certification experience."
            />
            <Feature
              icon={Users}
              title="Hands-on Labs"
              description="Practice in real environments with enterprise IT and networking equipment."
            />
          </div>
        </div>
      </div>

      {/* Contact Section */}
      <div id="contact" className="bg-gray-50 dark:bg-gray-800 py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 dark:text-white">Contact Us</h2>
              <p className="mt-4 text-lg text-gray-600 dark:text-gray-300">
                Ready to prepare for your certification exams? Contact us to learn about our expert-led training programs.
              </p>
              <dl className="mt-8 space-y-6">
                <ContactItem
                  icon={MapPin}
                  title="Address"
                  content="710 7th Street Clanton, AL 35045"
                />
                <ContactItem
                  icon={Phone}
                  title="Phone"
                  content="205.415.9470"
                />
                <ContactItem
                  icon={Mail}
                  title="Email"
                  content="cyberexperts@sigmacybercorp.com"
                />
              </dl>
            </div>
            <div className="bg-white dark:bg-gray-700 rounded-lg shadow-lg p-8">
              <ContactForm />
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}

function App() {
  return (
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/ai-training" element={<AITraining />} />
      <Route path="/certification-training" element={<CertificationTraining />} />
      <Route path="/it-support" element={<ITSupport />} />
      <Route path="/instructor" element={<Instructor />} />
      <Route path="/certification-training/ccna" element={<CCNACertification />} />
      <Route path="/certification-training/ccnp-enterprise" element={<CCNPEnterpriseCertification />} />
      <Route path="/certification-training/cisco-certified-cybersecurity-associate" element={<CiscoCyberAssociateCertification />} />
      <Route path="/certification-training/cisco-certified-cybersecurity-professional" element={<CiscoCyberProfessionalCertification />} />
      <Route path="/certification-training/comptia-security-plus" element={<CompTIASecurityPlusCertification />} />
      <Route path="/certification-training/fortinet-nse-4-network-security-professional" element={<FortinetNSE4Certification />} />
      <Route path="/certification-training/fortinet-nse-7-network-security" element={<FortinetNSE7Certification />} />
      <Route path="/certification-training/isaca-cisa" element={<CISACertification />} />
      <Route path="/cybersecurity" element={<Cybersecurity />} />
      <Route path="/certification-training/:courseId/register" element={<Registration />} />
      <Route path="/portal" element={<TrainingPortal />} />
      <Route path="/portal/dashboard" element={<PortalDashboard />} />
      <Route path="/admin" element={<AdminLogin />} />
      <Route path="/admin/dashboard" element={<AdminRoute><AdminDashboard /></AdminRoute>} />
      <Route path="/admin/users" element={<AdminRoute><AdminUsers /></AdminRoute>} />
      <Route path="/admin/courses" element={<AdminRoute><AdminCourses /></AdminRoute>} />
      <Route path="/admin/content" element={<AdminRoute><AdminContent /></AdminRoute>} />
      <Route path="/admin/settings" element={<AdminRoute><AdminSettings /></AdminRoute>} />
      <Route path="/sigma-ai" element={<SigmaAI />} />
      <Route path="/ai-training/fundamentals" element={<AIFundamentals />} />
      <Route path="/ai-training/advanced" element={<AIAdvanced />} />
      <Route path="/ai-training/enterprise" element={<AIEnterprise />} />
      <Route path="/terms" element={<TermsOfUse />} />
      <Route path="/privacy" element={<PrivacyPolicy />} />
      <Route path="/services/network-infrastructure" element={<NetworkInfrastructure />} />
      <Route path="/services/managed-services" element={<ManagedServices />} />
      <Route path="/services/cloud-services" element={<CloudServices />} />
      <Route path="/services/enterprise-cybersecurity" element={<EnterpriseCybersecurity />} />
      <Route path="/services/data-management" element={<DataManagement />} />
      <Route path="/services/end-user-support" element={<EndUserSupport />} />
    </Routes>
  );
}

interface FeatureProps {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  description: string;
}

function Feature({ icon: Icon, title, description }: FeatureProps) {
  return (
    <div className="text-center">
      <div className="flex justify-center">
        <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-lg">
          <Icon className="h-8 w-8 text-blue-600" />
        </div>
      </div>
      <h3 className="mt-6 text-lg font-medium text-gray-900 dark:text-white">{title}</h3>
      <p className="mt-2 text-base text-gray-500 dark:text-gray-300">{description}</p>
    </div>
  );
}

interface ContactItemProps {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  content: string;
}

function ContactItem({ icon: Icon, title, content }: ContactItemProps) {
  return (
    <div className="flex">
      <div className="flex-shrink-0">
        <Icon className="h-6 w-6 text-blue-600" />
      </div>
      <div className="ml-3">
        <dt className="text-lg font-medium text-gray-900 dark:text-white">{title}</dt>
        <dd className="mt-1 text-gray-500 dark:text-gray-300">{content}</dd>
      </div>
    </div>
  );
}


export default App