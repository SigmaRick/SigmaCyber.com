import React from 'react';
import { useNavigate } from 'react-router-dom';
import CertificationLayout from '../../components/CertificationLayout';
import { CheckCircle, Calendar } from 'lucide-react';

export default function AIEnterprise() {
  const navigate = useNavigate();

  return (
    <CertificationLayout
      title="Enterprise AI Solutions"
      description="Learn to build production-ready AI applications, focusing on scalability, security, and enterprise integration."
      image="https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&q=80"
    >
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Course Overview</h2>
          <p className="text-gray-600 dark:text-gray-300 mb-8">
            Build enterprise-grade AI solutions that scale. This course focuses on production deployment, security considerations, and enterprise integration patterns for AI applications.
          </p>

          <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Key Topics</h3>
          <ul className="space-y-3 mb-8">
            {[
              "Enterprise AI Architecture",
              "Scalability and Performance",
              "Security and Compliance",
              "Advanced Integration Patterns",
              "Monitoring and Analytics",
              "Deployment Strategies"
            ].map((topic, index) => (
              <li key={index} className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                <span className="ml-3 text-gray-600 dark:text-gray-300">{topic}</span>
              </li>
            ))}
          </ul>

          <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">What You'll Learn</h3>
          <div className="space-y-4 mb-8">
            <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
              <h4 className="font-semibold text-gray-900 dark:text-white mb-2">Enterprise Architecture</h4>
              <p className="text-gray-600 dark:text-gray-300">
                Design and implement scalable AI architectures suitable for enterprise deployment.
              </p>
            </div>
            <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
              <h4 className="font-semibold text-gray-900 dark:text-white mb-2">Security & Compliance</h4>
              <p className="text-gray-600 dark:text-gray-300">
                Implement enterprise-grade security measures and ensure compliance requirements are met.
              </p>
            </div>
            <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
              <h4 className="font-semibold text-gray-900 dark:text-white mb-2">Monitoring & Analytics</h4>
              <p className="text-gray-600 dark:text-gray-300">
                Set up comprehensive monitoring and analytics for AI applications in production.
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-8">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Course Details</h2>
          
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Duration</h3>
              <p className="text-gray-600 dark:text-gray-300">1 Day (8 Hours)</p>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Schedule</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Friday or Saturday, 9:00 AM - 5:00 PM
              </p>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Price</h3>
              <p className="text-3xl font-bold text-gray-900 dark:text-white mb-2">$495</p>
              <p className="text-gray-600 dark:text-gray-300">
                Includes enterprise course materials and resources
              </p>
            </div>

            <div className="border-t border-gray-200 dark:border-gray-700 pt-6">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Prerequisites</h3>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                  <span className="ml-3 text-gray-600 dark:text-gray-300">Completion of Advanced AI course or equivalent experience</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                  <span className="ml-3 text-gray-600 dark:text-gray-300">Enterprise development experience</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                  <span className="ml-3 text-gray-600 dark:text-gray-300">Understanding of security principles</span>
                </li>
              </ul>
            </div>

            <form onSubmit={(e) => {
              e.preventDefault();
              navigate('/certification-training/ai-enterprise/register');
            }}>
              <button
                type="submit"
                className="w-full bg-blue-600 text-white py-4 px-6 rounded-lg text-lg font-semibold hover:bg-blue-700 transition-colors"
              >
                Enroll Now
              </button>
            </form>
          </div>
        </div>
      </div>
    </CertificationLayout>
  );
}