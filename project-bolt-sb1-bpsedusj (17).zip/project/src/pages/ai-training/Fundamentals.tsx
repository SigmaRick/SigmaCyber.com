import React from 'react';
import { useNavigate } from 'react-router-dom';
import CertificationLayout from '../../components/CertificationLayout';
import { CheckCircle, Calendar } from 'lucide-react';

export default function AIFundamentals() {
  const navigate = useNavigate();

  return (
    <CertificationLayout
      title="AI Development Fundamentals"
      description="Learn the basics of AI development with Bolt, including prompt engineering, system design, and best practices."
      image="https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&q=80"
    >
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Course Overview</h2>
          <p className="text-gray-600 dark:text-gray-300 mb-8">
            Master the fundamentals of AI development with Bolt. This comprehensive one-day course provides hands-on experience building AI-powered applications and understanding core concepts of prompt engineering and system design.
          </p>

          <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Key Topics</h3>
          <ul className="space-y-3 mb-8">
            {[
              "Introduction to AI Development",
              "Understanding Prompt Engineering",
              "System Design with AI",
              "Best Practices and Patterns",
              "Building Basic AI Applications",
              "Integration with Web Applications"
            ].map((topic, index) => (
              <li key={index} className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                <span className="ml-3 text-gray-600 dark:text-gray-300">{topic}</span>
              </li>
            ))}
          </ul>

          <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">What You'll Learn</h3>
          <div className="space-y-4 mb-8">
            <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
              <h4 className="font-semibold text-gray-900 dark:text-white mb-2">Prompt Engineering</h4>
              <p className="text-gray-600 dark:text-gray-300">
                Learn to craft effective prompts for AI systems and understand how to optimize AI responses for your applications.
              </p>
            </div>
            <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
              <h4 className="font-semibold text-gray-900 dark:text-white mb-2">System Design</h4>
              <p className="text-gray-600 dark:text-gray-300">
                Understand how to architect applications that effectively leverage AI capabilities while maintaining performance and reliability.
              </p>
            </div>
            <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
              <h4 className="font-semibold text-gray-900 dark:text-white mb-2">Best Practices</h4>
              <p className="text-gray-600 dark:text-gray-300">
                Master the core principles and patterns for building robust AI applications that scale.
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-8">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Course Details</h2>
          
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Duration</h3>
              <p className="text-gray-600 dark:text-gray-300">1 Day (8 Hours)</p>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Schedule</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Friday or Saturday, 9:00 AM - 5:00 PM
              </p>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Price</h3>
              <p className="text-3xl font-bold text-gray-900 dark:text-white mb-2">$495</p>
              <p className="text-gray-600 dark:text-gray-300">
                Includes course materials and hands-on project resources
              </p>
            </div>

            <div className="border-t border-gray-200 dark:border-gray-700 pt-6">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Prerequisites</h3>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                  <span className="ml-3 text-gray-600 dark:text-gray-300">Basic programming knowledge</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                  <span className="ml-3 text-gray-600 dark:text-gray-300">Familiarity with web development</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                  <span className="ml-3 text-gray-600 dark:text-gray-300">Understanding of basic AI concepts</span>
                </li>
              </ul>
            </div>

            <form onSubmit={(e) => {
              e.preventDefault();
              navigate('/certification-training/ai-fundamentals/register');
            }}>
              <button
                type="submit"
                className="w-full bg-blue-600 text-white py-4 px-6 rounded-lg text-lg font-semibold hover:bg-blue-700 transition-colors"
              >
                Enroll Now
              </button>
            </form>
          </div>
        </div>
      </div>
    </CertificationLayout>
  );
}