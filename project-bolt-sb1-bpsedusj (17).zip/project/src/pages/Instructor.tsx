import React from 'react';
import { Link } from 'react-router-dom';
import { Award, BookOpen, Users, Brain } from 'lucide-react';
import { useEffect } from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';

export default function Instructor() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 pt-48">
      <Header />

      <div className="relative overflow-hidden bg-gradient-to-r from-blue-600 to-blue-800 py-24 mb-16 mt-32">
        <img
          src="https://images.unsplash.com/photo-1524178232363-1fb2b075b655?auto=format&fit=crop&q=80"
          alt="Professional consulting environment"
          className="absolute inset-0 w-full h-full object-cover mix-blend-overlay"
        />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-3xl mx-auto">
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">Meet Your Trusted Advisor</h1>
            <p className="text-2xl text-blue-100">Partner with an industry expert bringing over 25 years of enterprise IT and cybersecurity excellence</p>
          </div>
        </div>
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-gray-50 dark:to-gray-900" />
      </div>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
          <div>
            <div className="sticky top-8">
              <div className="w-96 h-96 rounded-xl overflow-hidden mb-6 mx-auto">
                <img
                  src="https://wkddnyxqlsewacuexjyi.supabase.co/storage/v1/object/public/images//Untitledrrrr.png"
                  alt="Rick Miller - Trusted Advisor"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex flex-wrap gap-3 justify-center">
                <div className="bg-blue-100 dark:bg-blue-900 px-4 py-2 rounded-full text-blue-900 dark:text-blue-100">CCNP Enterprise</div>
                <div className="bg-blue-100 dark:bg-blue-900 px-4 py-2 rounded-full text-blue-900 dark:text-blue-100">NSE 7</div>
                <div className="bg-blue-100 dark:bg-blue-900 px-4 py-2 rounded-full text-blue-900 dark:text-blue-100">CISA</div>
                <div className="bg-blue-100 dark:bg-blue-900 px-4 py-2 rounded-full text-blue-900 dark:text-blue-100">Security+</div>
              </div>
            </div>
          </div>

          <div className="space-y-12">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">Rick Miller</h2>
              <p className="text-2xl text-gray-600 dark:text-gray-300 mb-6">Trusted Advisor & Enterprise Security Expert</p>
              <p className="text-lg text-gray-600 dark:text-gray-300 leading-relaxed">
                With over 25 years of hands-on experience in enterprise IT and cybersecurity, Rick Miller brings unparalleled expertise from working with Fortune 500 companies, government agencies, and critical infrastructure. His extensive background includes leading complex network deployments, implementing enterprise security solutions, and managing mission-critical infrastructure for major organizations. Rick has also successfully deployed and managed large-scale Bitcoin mining operations with over 10,000 miners and implemented advanced AI solutions for enterprise environments. His comprehensive experience in both traditional IT infrastructure and cutting-edge technologies makes him an invaluable advisor for both professional development and enterprise solutions.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-gray-50 dark:bg-gray-800 p-6 rounded-xl">
                <div className="flex items-center gap-4 mb-4">
                  <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-lg">
                    <Award className="h-6 w-6 text-blue-600" />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 dark:text-white">Certifications</h3>
                </div>
                <ul className="space-y-4">
                  <li className="text-lg text-gray-600 dark:text-gray-300">Cisco CCNP Enterprise</li>
                  <li className="text-lg text-gray-600 dark:text-gray-300">Fortinet NSE 7</li>
                  <li className="text-lg text-gray-600 dark:text-gray-300">ISACA CISA</li>
                  <li className="text-lg text-gray-600 dark:text-gray-300">CompTIA Security+</li>
                  <li className="text-lg text-gray-600 dark:text-gray-300">AWS Solutions Architect</li>
                </ul>
              </div>

              <div className="bg-gray-50 dark:bg-gray-800 p-6 rounded-xl">
                <div className="flex items-center gap-4 mb-4">
                  <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-lg">
                    <BookOpen className="h-6 w-6 text-blue-600" />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 dark:text-white">Specializations</h3>
                </div>
                <ul className="space-y-4">
                  <li className="text-lg text-gray-600 dark:text-gray-300">Large-scale Bitcoin Mining Operations</li>
                  <li className="text-lg text-gray-600 dark:text-gray-300">Enterprise AI Implementation</li>
                  <li className="text-lg text-gray-600 dark:text-gray-300">Enterprise Security Architecture</li>
                  <li className="text-lg text-gray-600 dark:text-gray-300">Critical Infrastructure Protection</li>
                  <li className="text-lg text-gray-600 dark:text-gray-300">Compliance & Risk Management</li>
                </ul>
              </div>
            </div>

            <div>
              <h3 className="text-3xl font-bold text-gray-900 dark:text-white mb-6">Teaching Philosophy</h3>
              <div className="space-y-6">
                <p className="text-lg text-gray-600 dark:text-gray-300 leading-relaxed">
                  My advisory approach combines deep technical expertise with strategic business understanding. Drawing from over 25 years of enterprise experience, including large-scale Bitcoin mining operations and AI implementations, I help organizations and professionals navigate the complex landscape of modern technology while ensuring practical, results-driven solutions.
                </p>
                <p className="text-lg text-gray-600 dark:text-gray-300 leading-relaxed">
                  Whether you're pursuing professional certifications, planning a cryptocurrency mining operation, implementing AI solutions, or seeking enterprise IT infrastructure guidance, my expertise is grounded in real-world experience from working with Fortune 500 companies, managing large-scale mining operations, and implementing cutting-edge AI systems.
                </p>
              </div>
            </div>

            <div>
              <h3 className="text-3xl font-bold text-gray-900 dark:text-white mb-6">Teaching Methodology</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="flex justify-center mb-4">
                    <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-lg">
                      <Brain className="h-6 w-6 text-blue-600" />
                    </div>
                  </div>
                  <h4 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">Strategic Guidance</h4>
                  <p className="text-lg text-gray-600 dark:text-gray-300">Expert advice based on enterprise experience</p>
                </div>
                <div className="text-center">
                  <div className="flex justify-center mb-4">
                    <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-lg">
                      <Users className="h-6 w-6 text-blue-600" />
                    </div>
                  </div>
                  <h4 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">Personalized Solutions</h4>
                  <p className="text-lg text-gray-600 dark:text-gray-300">Tailored advice for your specific needs</p>
                </div>
                <div className="text-center">
                  <div className="flex justify-center mb-4">
                    <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-lg">
                      <Award className="h-6 w-6 text-blue-600" />
                    </div>
                  </div>
                  <h4 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">Enterprise Expertise</h4>
                  <p className="text-lg text-gray-600 dark:text-gray-300">Fortune 500 and government experience</p>
                </div>
              </div>
            </div>

            <div className="bg-blue-50 dark:bg-blue-900/30 p-8 rounded-xl">
              <h3 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">Ready to Get Started?</h3>
              <p className="text-xl text-gray-600 dark:text-gray-300 mb-6">
                Join our next certification class and begin your journey toward becoming a certified IT professional.
              </p>
              <Link
                to="/certification-training"
                className="inline-flex items-center px-6 py-3 border border-transparent text-lg font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 transition-colors"
              >
                View Available Courses
              </Link>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}