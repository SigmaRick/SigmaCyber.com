import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Calendar, CreditCard, User, Mail, Phone, Building, FileText, CheckCircle } from 'lucide-react';
import { sendEmail } from '../utils/email';
import CertificationLayout from '../components/CertificationLayout';

const courseInfo = {
  'ccna': {
    title: 'Cisco CCNA Certification',
    shortTitle: 'Cisco CCNA',
    price: '$4,995',
    duration: '96 Hours (6 Weeks)',
    image: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&q=80'
  },
  'ccnp-enterprise': {
    title: 'Cisco CCNP Enterprise Certification',
    shortTitle: 'Cisco CCNP Enterprise',
    price: '$7,995',
    duration: '192 Hours (12 Weeks)',
    image: 'https://images.unsplash.com/photo-1520869562399-e772f042f422?auto=format&fit=crop&q=80'
  },
  'cisco-certified-cybersecurity-associate': {
    title: 'Cisco Certified Cybersecurity Associate',
    shortTitle: 'Cisco Cybersecurity Associate',
    price: '$4,995',
    duration: '8 Weeks (Part-time)',
    image: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&q=80'
  },
  'cisco-certified-cybersecurity-professional': {
    title: 'Cisco Certified Cybersecurity Professional',
    shortTitle: 'Cisco Cybersecurity Professional',
    price: '$9,995',
    duration: '24 Weeks (Part-time)',
    image: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80'
  },
  'fortinet-nse-4-network-security-professional': {
    title: 'Fortinet NSE 4 Network Security Professional',
    shortTitle: 'Fortinet NSE 4',
    price: '$4,995',
    duration: '96 Hours (6 Weeks)',
    image: 'https://images.unsplash.com/photo-1562813733-b31f71025d54?auto=format&fit=crop&q=80'
  },
  'fortinet-nse-7-network-security': {
    title: 'Fortinet NSE 7 Network Security',
    shortTitle: 'Fortinet NSE 7',
    price: '$7,995',
    duration: '192 Hours (12 Weeks)',
    image: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80'
  },
  'comptia-security-plus': {
    title: 'CompTIA Security+ Certification',
    shortTitle: 'CompTIA Security+',
    price: '$3,995',
    duration: '96 Hours (6 Weeks)',
    image: 'https://images.unsplash.com/photo-1614064641938-3bbee52942c7?auto=format&fit=crop&q=80'
  },
  'isaca-cisa': {
    title: 'ISACA CISA Certification',
    shortTitle: 'ISACA CISA',
    price: '$3,499',
    duration: '16 Weeks (Part-time)',
    image: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&q=80'
  },
  'ai-fundamentals': {
    title: 'AI Development Fundamentals',
    shortTitle: 'AI Fundamentals',
    price: '$495',
    duration: '1 Day (8 Hours)',
    image: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&q=80'
  },
  'ai-advanced': {
    title: 'Advanced AI Application Development',
    shortTitle: 'Advanced AI',
    price: '$495',
    duration: '1 Day (8 Hours)',
    image: 'https://images.unsplash.com/photo-1620712943543-bcc4688e7485?auto=format&fit=crop&q=80'
  },
  'ai-enterprise': {
    title: 'Enterprise AI Solutions',
    shortTitle: 'Enterprise AI',
    price: '$495',
    duration: '1 Day (8 Hours)',
    image: 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&q=80'
  }
};

export default function Registration() {
  const { courseId } = useParams();
  const navigate = useNavigate();
  const course = courseInfo[courseId as keyof typeof courseInfo];
  const [step, setStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [status, setStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [formData, setFormData] = useState({
    name: '',
    from_email: '',
    certificationInterest: courseId || '',
    phone: '',
    company: '',
    experience: '',
    startDate: '',
    classSchedule: '',
    paymentMethod: '',
    comments: ''
  });

  if (!course) {
    return <div>Course not found</div>;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (step < 3) {
      setStep(step + 1);
    } else {
      setIsSubmitting(true);
      setStatus('idle');
      
      try {
        const data = {
          from_name: formData.name,
          from_email: formData.from_email,
          phone: formData.phone,
          company: formData.company,
          inquiry_type: 'training',
          message: `
Course: ${course.title}
Name: ${formData.name}
Email: ${formData.from_email}
Phone: ${formData.phone}
Company: ${formData.company}
Class Schedule: ${formData.classSchedule}
Start Date: ${formData.startDate}
Experience: ${formData.experience}
Payment Method: ${formData.paymentMethod}

Additional Comments:
${formData.comments}
        `.trim(),
          certificationInterest: courseInfo[formData.certificationInterest as keyof typeof courseInfo].title,
        };
        
        await sendEmail(data, "template_urxs95c");
        
        setStatus('success');
        setTimeout(() => {
          navigate('/certification-training');
        }, 3000);
      } catch (error) {
        setStatus('error');
        console.error('Error sending registration:', error);
      } finally {
        setIsSubmitting(false);
      }
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <CertificationLayout
      title={`Register for ${course.title}`}
      description="Complete your registration for the certification program"
      image={course.image}
    >
      <div className="max-w-3xl mx-auto">
        {/* Progress Steps */}
        <div className="mb-8">
          <div className="flex items-center justify-between relative">
            <div className="absolute left-0 right-0 top-1/2 h-0.5 bg-gray-200 dark:bg-gray-700 -translate-y-1/2" />
            <div className="relative flex items-center justify-center w-10 h-10 rounded-full bg-blue-600 text-white">
              <User className="w-5 h-5" />
            </div>
            <div className={`relative flex items-center justify-center w-10 h-10 rounded-full ${step >= 2 ? 'bg-blue-600 text-white' : 'bg-gray-200 dark:bg-gray-700 text-gray-500'}`}>
              <Calendar className="w-5 h-5" />
            </div>
            <div className={`relative flex items-center justify-center w-10 h-10 rounded-full ${step === 3 ? 'bg-blue-600 text-white' : 'bg-gray-200 dark:bg-gray-700 text-gray-500'}`}>
              <CreditCard className="w-5 h-5" />
            </div>
          </div>
          <div className="flex justify-between mt-2">
            <span className="text-sm font-medium text-gray-900 dark:text-white">Personal Info</span>
            <span className="text-sm font-medium text-gray-900 dark:text-white">Schedule</span>
            <span className="text-sm font-medium text-gray-900 dark:text-white">Payment</span>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {step === 1 && (
            <div className="space-y-6">
              <div>
                <label htmlFor="certificationInterest" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Certification Interest</label>
                <select
                  name="certificationInterest"
                  id="certificationInterest"
                  required
                  value={formData.certificationInterest}
                  onChange={handleInputChange}
                  className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                >
                  <option value="">Select certification</option>
                  {Object.entries(courseInfo).map(([id, info]) => (
                    <option key={id} value={id}>{info.shortTitle}</option>
                  ))}
                </select>
              </div>
              <div>
                <label htmlFor="phone" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Phone</label>
                <input
                  type="tel"
                  name="phone"
                  id="phone"
                  required
                  value={formData.phone}
                  onChange={handleInputChange}
                  className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                />
              </div>
              <div>
                <label htmlFor="company" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Company (Optional)</label>
                <input
                  type="text"
                  name="company"
                  id="company"
                  value={formData.company}
                  onChange={handleInputChange}
                  className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                />
              </div>
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Name</label>
                <input
                  type="text"
                  name="name"
                  id="name"
                  required
                  value={formData.name}
                  onChange={handleInputChange}
                  className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                />
              </div>
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Email</label>
                <input
                  type="email"
                  name="from_email"
                  id="email"
                  required
                  value={formData.from_email}
                  onChange={handleInputChange}
                  className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                />
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6">
              <div>
                <label htmlFor="experience" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Years of Experience</label>
                <select
                  name="experience"
                  id="experience"
                  required
                  value={formData.experience}
                  onChange={handleInputChange}
                  className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                >
                  <option value="">Select experience</option>
                  <option value="0-1">0-1 years</option>
                  <option value="1-3">1-3 years</option>
                  <option value="3-5">3-5 years</option>
                  <option value="5+">5+ years</option>
                </select>
              </div>
              <div>
                <label htmlFor="startDate" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Preferred Start Date</label>
                <select
                  name="startDate"
                  id="startDate"
                  required
                  value={formData.startDate}
                  onChange={handleInputChange}
                  className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                >
                  <option value="">Select start date</option>
                  <option value="2025-05-05">May 5, 2025</option>
                  <option value="2025-06-16">June 16, 2025</option>
                  <option value="2025-07-28">July 28, 2025</option>
                  <option value="2025-09-08">September 8, 2025</option>
                </select>
              </div>
              <div>
                <label htmlFor="classSchedule" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Class Schedule</label>
                <select
                  name="classSchedule"
                  id="classSchedule"
                  required
                  value={formData.classSchedule}
                  onChange={handleInputChange}
                  className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                >
                  <option value="">Select schedule</option>
                  <option value="morning">Morning Classes: Monday - Thursday, 8:00 AM - 12:00 PM</option>
                  <option value="evening">Evening Classes: Monday - Thursday, 6:00 PM - 10:00 PM</option>
                  <option value="friday">Friday, 9:00 AM - 5:00 PM</option>
                  <option value="saturday">Saturday, 9:00 AM - 5:00 PM</option>
                </select>
              </div>
              <div>
                <label htmlFor="comments" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Additional Comments</label>
                <textarea
                  name="comments"
                  id="comments"
                  rows={4}
                  value={formData.comments}
                  onChange={handleInputChange}
                  className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                />
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-6">
              <div>
                <label htmlFor="paymentMethod" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Payment Method</label>
                <select
                  name="paymentMethod"
                  id="paymentMethod"
                  required
                  value={formData.paymentMethod}
                  onChange={handleInputChange}
                  className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                >
                  <option value="">Select payment method</option>
                  <option value="credit-card">Credit Card</option>
                  <option value="bank-transfer">Bank Transfer</option>
                  <option value="company-invoice">Company Invoice</option>
                </select>
              </div>

              <div className="bg-gray-50 dark:bg-gray-700 p-6 rounded-lg">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Order Summary</h3>
                <div className="space-y-3">
                  <div className="bg-blue-50 dark:bg-blue-900/50 p-4 rounded-lg mb-4">
                    <p className="text-sm text-blue-800 dark:text-blue-200">
                      Note: A Sigma Cyber representative will contact you to schedule a meet and greet session and finalize payment arrangements for the class.
                    </p>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-300">Course</span>
                    <span className="text-gray-900 dark:text-white font-medium">{course.title}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-300">Duration</span>
                    <span className="text-gray-900 dark:text-white font-medium">{course.duration}</span>
                  </div>
                  <div className="flex justify-between border-t border-gray-200 dark:border-gray-600 pt-3">
                    <span className="text-gray-900 dark:text-white font-semibold">Total</span>
                    <span className="text-gray-900 dark:text-white font-semibold">{course.price}</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          <div className="flex justify-between pt-6">
            {step > 1 && (
              <button
                type="button"
                onClick={() => setStep(step - 1)}
                className="px-6 py-3 border border-gray-300 dark:border-gray-600 text-base font-medium rounded-md text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
              >
                Back
              </button>
            )}
            <button
              type="submit"
              disabled={isSubmitting}
              className="ml-auto px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 transition-colors"
            >
              {isSubmitting ? 'Submitting...' : step === 3 ? 'Complete Registration' : 'Continue'}
            </button>
          </div>

          {status === 'success' && (
            <div className="mt-4 p-4 bg-green-50 dark:bg-green-900/30 text-green-800 dark:text-green-200 rounded-md">
              Registration submitted successfully! We'll contact you shortly to finalize your enrollment. Redirecting...
            </div>
          )}

          {status === 'error' && (
            <div className="mt-4 p-4 bg-red-50 dark:bg-red-900/30 text-red-800 dark:text-red-200 rounded-md">
              There was an error submitting your registration. Please try again or contact us directly.
            </div>
          )}
        </form>
      </div>
    </CertificationLayout>
  );
}