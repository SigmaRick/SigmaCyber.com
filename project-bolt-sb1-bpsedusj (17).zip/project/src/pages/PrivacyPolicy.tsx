import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';

export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen bg-white dark:bg-gray-900">
      <Header />
      <div className="h-32"></div>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-8">Privacy Policy</h1>
        
        <div className="prose dark:prose-invert max-w-none text-gray-900 dark:text-gray-200">
          <p>Last updated: January 1, 2025</p>

          <h2>1. Information We Collect</h2>
          <p>We collect information that you provide directly to us, including:</p>
          <ul>
            <li>Name and contact information</li>
            <li>Professional and educational background</li>
            <li>Payment information</li>
            <li>Course enrollment and progress data</li>
          </ul>

          <h2>2. How We Use Your Information</h2>
          <p>We use the information we collect to:</p>
          <ul>
            <li>Provide and manage our services</li>
            <li>Process your payments</li>
            <li>Send you updates about your courses</li>
            <li>Improve our services</li>
            <li>Comply with legal obligations</li>
          </ul>

          <h2>3. Information Sharing</h2>
          <p>We do not sell your personal information. We may share your information with:</p>
          <ul>
            <li>Service providers who assist in our operations</li>
            <li>Certification authorities when required for exam registration</li>
            <li>Law enforcement when required by law</li>
          </ul>

          <h2>4. Data Security</h2>
          <p>We implement appropriate technical and organizational measures to protect your personal information against unauthorized access, alteration, or destruction.</p>

          <h2>5. Your Rights</h2>
          <p>You have the right to:</p>
          <ul>
            <li>Access your personal information</li>
            <li>Correct inaccurate information</li>
            <li>Request deletion of your information</li>
            <li>Opt-out of marketing communications</li>
          </ul>

          <h2>6. Cookies and Tracking</h2>
          <p>We use cookies and similar technologies to improve user experience and analyze website traffic. You can control cookie preferences through your browser settings.</p>

          <h2>7. Changes to Privacy Policy</h2>
          <p>We may update this privacy policy from time to time. We will notify you of any changes by posting the new policy on this page.</p>

          <h2>8. Contact Us</h2>
          <p>For questions about this Privacy Policy, please contact us at:</p>
          <ul>
            <li>Email: privacy@sigmacybercorp.com</li>
            <li>Phone: 205.415.9470</li>
            <li>Address: 710 7th Street Clanton, AL 35045</li>
          </ul>
        </div>
      </main>

      <Footer />
    </div>
  );
}