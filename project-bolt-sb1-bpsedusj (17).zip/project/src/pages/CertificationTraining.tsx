import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useEffect } from 'react';
import { Brain, Award, Users, CheckCircle, Network, Lock, BarChart, ChevronRight, Shield } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';

interface CertificationSectionProps {
  title: string;
  slug?: string;
  description: string;
  topics: string[];
  duration: string;
  price: string;
  prerequisites?: string[];
}

function CertificationSection({ title, slug, description, topics, duration, price, prerequisites }: CertificationSectionProps) {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
      <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">{title}</h3>
      <p className="text-gray-600 dark:text-gray-300 mb-6">{description}</p>
      
      <div className="space-y-6 mb-6">
        <div>
          <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">Key Topics</h4>
          <ul className="space-y-2">
            {topics.map((topic, index) => (
              <li key={index} className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                <span className="ml-3 text-gray-600 dark:text-gray-300">{topic}</span>
              </li>
            ))}
          </ul>
        </div>

        {prerequisites && prerequisites.length > 0 && (
          <div>
            <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">Prerequisites</h4>
            <ul className="list-disc list-inside space-y-2">
              {prerequisites.map((prereq, index) => (
                <li key={index} className="text-gray-600 dark:text-gray-300">{prereq}</li>
              ))}
            </ul>
          </div>
        )}

        <div className="grid grid-cols-2 gap-4">
          <div>
            <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Duration</h4>
            <p className="text-gray-600 dark:text-gray-300">{duration}</p>
          </div>
          <div>
            <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Price</h4>
            <p className="text-gray-600 dark:text-gray-300">{price}</p>
          </div>
        </div>
      </div>
      
      {slug ? (
        <Link
          to={`/certification-training/${slug}`}
          className="w-full bg-blue-600 text-white py-3 px-4 rounded-md hover:bg-blue-700 transition-colors inline-block text-center flex items-center justify-center gap-2"
        >
          Learn More
          <ChevronRight className="h-5 w-5" />
        </Link>
      ) : (
        <button
          onClick={() => alert("This certification course is coming soon!")}
          className="w-full bg-blue-600 text-white py-3 px-4 rounded-md hover:bg-blue-700 transition-colors inline-block text-center"
        >
          Coming Soon
        </button>
      )}
    </div>
  );
}

export default function CertificationTraining() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 pt-48 pb-16">
      <Header />

      <div className="relative overflow-hidden bg-gradient-to-r from-blue-600 to-blue-800 py-24 mb-16 mt-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-3xl mx-auto">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Certification Training Programs
            </h1>
            <p className="text-xl text-blue-100 mb-8">
            Advance your career with industry-recognized certifications
            </p>
          </div>
        </div>
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-gray-50 dark:to-gray-900" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <div className="relative h-[400px] rounded-xl overflow-hidden mb-16">
            <img
              src="https://images.unsplash.com/photo-1544197150-b99a580bb7a8?auto=format&fit=crop&q=80"
              alt="High-tech data center training facility"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-gray-900/60 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-8 text-white text-left">
              <h2 className="text-3xl font-extrabold mb-2">Enterprise-Grade Training Environment</h2>
              <p className="text-xl font-bold text-white">Get hands-on experience with Cisco networking and Fortinet security equipment</p>
            </div>
          </div>
        </div>

        <div className="mt-16 space-y-12">
          {/* Cisco Certifications */}
          <div className="bg-gradient-to-r from-blue-50 to-transparent dark:from-blue-900/20 dark:to-transparent p-8 rounded-2xl">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-8 flex items-center gap-3">
              <Network className="h-8 w-8 text-blue-600" />
              Cisco Certifications
            </h2>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <CertificationSection
            title="Cisco CCNA Certification"
            slug="ccna"
            description="Comprehensive training for the Cisco Certified Network Associate certification, covering networking fundamentals, security basics, and automation concepts."
            topics={[
              "Network Fundamentals and Access",
              "IP Connectivity and Services",
              "Security Fundamentals",
              "Network Automation and Programmability",
              "Hands-on Lab Experience",
              "Practice Exam Simulations"
            ]}
            duration="96 Hours (6 Weeks)"
            price="$4,995"
            prerequisites={[
              "Basic computer knowledge",
              "Understanding of basic networking concepts"
            ]}
          />
          <CertificationSection
            title="Cisco CCNP Enterprise Certification"
            slug="ccnp-enterprise"
            description="Advanced enterprise networking certification covering complex enterprise networking solutions, infrastructure planning, and implementation of Cisco solutions."
            topics={[
              "Advanced Routing and Services",
              "Enterprise Network Design",
              "Network Virtualization",
              "Infrastructure Security",
              "SD-WAN Architecture",
              "Advanced Troubleshooting Techniques"
            ]}
            duration="192 Hours (12 Weeks)"
            price="$7,995"
            prerequisites={[
              "Valid Cisco CCNA certification",
              "3+ years of networking experience",
              "Understanding of enterprise network architecture"
            ]}
          />
            </div>
          </div>
          
          {/* Cisco Security Certifications */}
          <div className="bg-gradient-to-r from-green-50 to-transparent dark:from-green-900/20 dark:to-transparent p-8 rounded-2xl">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-8 flex items-center gap-3">
              <Shield className="h-8 w-8 text-green-600" />
              Cisco Security Certifications
            </h2>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <CertificationSection
            title="Cisco Certified Cybersecurity Associate"
            slug="cisco-certified-cybersecurity-associate"
            description="Entry-level cybersecurity certification providing foundational knowledge in network security, threat detection, and cybersecurity best practices."
            topics={[
              "Security Concepts and Principles",
              "Network Foundation Protection",
              "Cryptography Fundamentals",
              "Access Control and Authentication",
              "Security Monitoring and Analytics",
              "Incident Response Basics"
            ]}
            duration="96 Hours (6 Weeks)"
            price="$4,995"
            prerequisites={[
              "Basic IT knowledge",
              "Fundamental networking concepts",
              "Interest in cybersecurity"
            ]}
          />
          <CertificationSection
            title="Cisco Certified Cybersecurity Professional"
            slug="cisco-certified-cybersecurity-professional"
            description="Comprehensive cybersecurity certification program focusing on threat detection, network security, and implementing Cisco security solutions."
            topics={[
              "Network Security Architecture",
              "Endpoint Protection and Detection",
              "Secure Network Access",
              "VPN and Encryption Technologies",
              "Cloud Security",
              "Security Operations and Monitoring"
            ]}
            duration="192 Hours (12 Weeks)"
            price="$9,995"
            prerequisites={[
              "Basic networking knowledge",
              "Understanding of security concepts",
              "Familiarity with Cisco security products"
            ]}
          />
            </div>
          </div>
          
          {/* Fortinet Certifications */}
          <div className="bg-gradient-to-r from-purple-50 to-transparent dark:from-purple-900/20 dark:to-transparent p-8 rounded-2xl">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-8 flex items-center gap-3">
              <Lock className="h-8 w-8 text-purple-600" />
              Fortinet Certifications
            </h2>
          <CertificationSection
            title="Fortinet NSE 4 Network Security Professional"
            slug="fortinet-nse-4-network-security-professional"
            description="Expert-led training for Fortinet NSE 4 certification, focusing on FortiGate network security platform and security infrastructure."
            topics={[
              "FortiGate Security Features",
              "Firewall Policies and Authentication",
              "Network Security",
              "SSL VPN and IPsec VPN",
              "Security Profiles and Web Filtering",
              "Threat Protection and Inspection"
            ]}
            duration="96 Hours (6 Weeks)"
            price="$4,995"
            prerequisites={[
              "Network security fundamentals",
              "Basic networking knowledge"
            ]}
          />
          <CertificationSection
            title="Fortinet NSE 7 - Network Security"
            slug="fortinet-nse-7-network-security"
            description="Advanced Fortinet certification focusing on complex network security implementations, enterprise firewall infrastructure, and advanced threat protection."
            topics={[
              "Advanced FortiGate Enterprise Firewall",
              "Advanced Routing and Switching",
              "High Availability and SDN",
              "Advanced Threat Protection",
              "Enterprise Security Management",
              "Performance Optimization"
            ]}
            duration="192 Hours (12 Weeks)"
            price="$7,995"
            prerequisites={[
              "Valid NSE 4 certification",
              "3+ years of network security experience",
              "Strong understanding of enterprise networks"
            ]}
          />
          </div>
          
          {/* ISACA Certifications */}
          <div className="bg-gradient-to-r from-red-50 to-transparent dark:from-red-900/20 dark:to-transparent p-8 rounded-2xl">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-8 flex items-center gap-3">
              <Shield className="h-8 w-8 text-red-600" />
              CompTIA Certifications
            </h2>
          <CertificationSection
            title="CompTIA Security+"
            slug="comptia-security-plus"
            description="Industry-leading certification validating baseline cybersecurity skills and knowledge required for IT security roles."
            topics={[
              "Network Security",
              "Compliance and Operational Security",
              "Threats and Vulnerabilities",
              "Application, Data, and Host Security",
              "Access Control and Identity Management",
              "Cryptography and PKI"
            ]}
            duration="96 Hours (6 Weeks)"
            price="$3,995"
            prerequisites={[
              "CompTIA Network+ certification recommended",
              "2 years of IT administration experience recommended",
              "Basic IT security knowledge"
            ]}
          />
          </div>
          
          {/* ISACA Certifications */}
          <div className="bg-gradient-to-r from-orange-50 to-transparent dark:from-orange-900/20 dark:to-transparent p-8 rounded-2xl">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-8 flex items-center gap-3">
              <BarChart className="h-8 w-8 text-orange-600" />
              ISACA Certifications
            </h2>
          <CertificationSection
            title="ISACA CISA Certification"
            slug="isaca-cisa"
            description="Comprehensive preparation for the Certified Information Systems Auditor examination, covering IT audit processes and information systems governance."
            topics={[
              "Information Systems Auditing Process",
              "IT Governance and Management",
              "Information Systems Acquisition and Implementation",
              "Information Systems Operations and Business Resilience",
              "Protection of Information Assets",
              "Real-world Case Studies"
            ]}
            duration="96 Hours (6 Weeks)"
            price="$4,995"
            prerequisites={[
              "5 years of professional information systems auditing experience",
              "Basic understanding of IT controls"
            ]}
          />
          </div>
        </div>

        <Footer />
      </div>
    </div>
  );
}