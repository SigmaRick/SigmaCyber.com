import React from 'react';
import { CheckCircle, Calendar } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import CertificationLayout from '../../components/CertificationLayout';
import { useEffect } from 'react';
import { DayPicker } from 'react-day-picker';
import 'react-day-picker/dist/style.css';

export default function CiscoCyberProfessionalCertification() {
  const navigate = useNavigate();
  
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const startDates = [
    new Date(2025, 4, 5), // May 5, 2025
    new Date(2025, 6, 8), // July 8, 2025
    new Date(2025, 8, 15), // September 15, 2025
    new Date(2025, 10, 4), // November 4, 2025
  ];

  const footer = (
    <div className="mt-4 text-center text-gray-600 dark:text-gray-300">
      Available start dates are highlighted
    </div>
  );

  return (
    <CertificationLayout
      title="Cisco Certified Cybersecurity Professional"
      description="Advanced enterprise security certification covering complex security architecture, threat detection, and implementing comprehensive security solutions."
      image="https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80"
    >
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Course Overview</h2>
          <p className="text-gray-600 dark:text-gray-300 mb-8">
            The Cisco Certified Cybersecurity Professional certification validates your ability to design, implement, and maintain advanced security solutions. This comprehensive course provides hands-on experience with enterprise security tools and prepares you for the certification exam.
          </p>

          <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Key Topics</h3>
          <ul className="space-y-3 mb-8">
            {[
              "Advanced Network Security Architecture",
              "Enterprise Threat Detection Systems",
              "Cloud Security and Zero Trust",
              "Security Information and Event Management (SIEM)",
              "Incident Response and Forensics",
              "Advanced Malware Protection",
              "Security Automation and Orchestration",
              "Compliance and Risk Management"
            ].map((topic, index) => (
              <li key={index} className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                <span className="ml-3 text-gray-600 dark:text-gray-300">{topic}</span>
              </li>
            ))}
          </ul>

          <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Prerequisites</h3>
          <ul className="list-disc list-inside space-y-2 mb-8">
            {[
              "Valid Cisco Certified Cybersecurity Associate certification",
              "3+ years of cybersecurity experience",
              "Strong understanding of network security concepts",
              "Familiarity with Cisco security products and solutions"
            ].map((prereq, index) => (
              <li key={index} className="text-gray-600 dark:text-gray-300">{prereq}</li>
            ))}
          </ul>

          <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Career Outlook in Alabama</h3>
          <div className="space-y-6 mb-8">
            <div>
              <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Average Salaries</h4>
              <ul className="space-y-2">
                <li className="flex justify-between items-center bg-gray-50 dark:bg-gray-700 p-3 rounded">
                  <span className="text-gray-600 dark:text-gray-300">Senior Security Engineer</span>
                  <span className="font-semibold text-gray-900 dark:text-white">$110,000 - $140,000</span>
                </li>
                <li className="flex justify-between items-center bg-gray-50 dark:bg-gray-700 p-3 rounded">
                  <span className="text-gray-600 dark:text-gray-300">Security Architect</span>
                  <span className="font-semibold text-gray-900 dark:text-white">$130,000 - $160,000</span>
                </li>
                <li className="flex justify-between items-center bg-gray-50 dark:bg-gray-700 p-3 rounded">
                  <span className="text-gray-600 dark:text-gray-300">Cybersecurity Manager</span>
                  <span className="font-semibold text-gray-900 dark:text-white">$120,000 - $150,000</span>
                </li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Current Job Openings</h4>
              <div className="space-y-4">
                <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded">
                  <h5 className="font-semibold text-gray-900 dark:text-white">Senior Security Engineer</h5>
                  <p className="text-gray-600 dark:text-gray-300 text-sm mb-2">NASA - Huntsville, AL</p>
                  <p className="text-gray-600 dark:text-gray-300 mb-2">Lead security architecture design, implement advanced threat detection systems, and manage security operations for space mission systems.</p>
                  <p className="text-blue-600 dark:text-blue-400">$130,000 - $155,000</p>
                </div>
                
                <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded">
                  <h5 className="font-semibold text-gray-900 dark:text-white">Cybersecurity Architect</h5>
                  <p className="text-gray-600 dark:text-gray-300 text-sm mb-2">Lockheed Martin - Huntsville, AL</p>
                  <p className="text-gray-600 dark:text-gray-300 mb-2">Design and implement enterprise security architecture, lead security initiatives, and develop advanced security strategies.</p>
                  <p className="text-blue-600 dark:text-blue-400">$140,000 - $170,000</p>
                </div>
                
                <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded">
                  <h5 className="font-semibold text-gray-900 dark:text-white">Security Operations Manager</h5>
                  <p className="text-gray-600 dark:text-gray-300 text-sm mb-2">Regions Bank - Birmingham, AL</p>
                  <p className="text-gray-600 dark:text-gray-300 mb-2">Lead security operations team, implement advanced security controls, and manage incident response for financial systems.</p>
                  <p className="text-blue-600 dark:text-blue-400">$125,000 - $155,000</p>
                </div>
              </div>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Industry Growth</h4>
              <p className="text-gray-600 dark:text-gray-300">
                Senior cybersecurity positions in Alabama are experiencing exceptional growth, with a 30% increase projected through 2025. Huntsville's defense and aerospace sector, along with Birmingham's financial industry, are creating high demand for advanced cybersecurity professionals.
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-8">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Course Details</h2>
          
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Duration</h3>
              <p className="text-gray-600 dark:text-gray-300">192 Hours (12 Weeks)</p>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Schedule</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Morning Classes: Monday - Thursday, 8:00 AM - 12:00 PM<br />
                Evening Classes: Monday - Thursday, 6:00 PM - 10:00 PM
              </p>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Price</h3>
              <p className="text-3xl font-bold text-gray-900 dark:text-white mb-2">$9,995</p>
              <p className="text-gray-600 dark:text-gray-300">
                Includes all course materials, lab access, and practice exams
              </p>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Next Start Date</h3>
              <p className="text-gray-600 dark:text-gray-300">July 28, 2025</p>
            </div>

            <div className="border-t border-gray-200 dark:border-gray-700 pt-6">
              <div className="flex items-center gap-2 mb-4">
                <Calendar className="h-5 w-5 text-blue-600" />
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Available Start Dates</h3>
              </div>
              <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                <DayPicker
                  mode="multiple"
                  selected={startDates}
                  footer={footer}
                  fromMonth={new Date()}
                  disabled={[
                    { before: new Date() },
                    (date) => !startDates.some(d => 
                      d.getFullYear() === date.getFullYear() &&
                      d.getMonth() === date.getMonth() &&
                      d.getDate() === date.getDate()
                    )
                  ]}
                  modifiers={{
                    highlight: startDates
                  }}
                  modifiersStyles={{
                    highlight: {
                      backgroundColor: '#2563eb',
                      color: 'white',
                      borderRadius: '4px'
                    }
                  }}
                  styles={{
                    caption: { color: 'inherit' },
                    head: { color: 'inherit' },
                    day: { color: 'inherit' }
                  }}
                  className="mx-auto"
                />
              </div>
            </div>

            <form onSubmit={(e) => {
              e.preventDefault();
              navigate('/certification-training/cisco-certified-cybersecurity-professional/register');
            }}>
              <button
                type="submit"
                className="w-full bg-blue-600 text-white py-4 px-6 rounded-lg text-lg font-semibold hover:bg-blue-700 transition-colors"
              >
                Enroll Now
              </button>
            </form>
          </div>
        </div>
      </div>
    </CertificationLayout>
  );
}