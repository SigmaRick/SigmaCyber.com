import React from 'react';
import { CheckCircle, Calendar } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import CertificationLayout from '../../components/CertificationLayout';
import { useEffect } from 'react';
import { DayPicker } from 'react-day-picker';
import 'react-day-picker/dist/style.css';
import { format } from 'date-fns';

function CCNACertification() {
  const navigate = useNavigate();
  
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  const startDates = [
    new Date(2025, 4, 5), // May 5, 2025
    new Date(2025, 5, 16), // June 16, 2025
    new Date(2025, 6, 28), // July 28, 2025
    new Date(2025, 8, 8), // September 8, 2025
  ];

  const footer = (
    <div className="mt-4 text-center text-gray-600 dark:text-gray-300">
      Available start dates are highlighted
    </div>
  );

  return (
    <CertificationLayout
      title="Cisco CCNA Certification"
      description="Comprehensive training for the Cisco Certified Network Associate certification, covering networking fundamentals, security basics, and automation concepts."
      image="https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&q=80"
    >
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Course Overview</h2>
          <p className="text-gray-600 dark:text-gray-300 mb-8">
            The Cisco CCNA certification is your first step toward a career in networking. This comprehensive course provides hands-on experience with Cisco equipment and prepares you for the CCNA exam.
          </p>

          <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Key Topics</h3>
          <ul className="space-y-3 mb-8">
            {[
              "Network Fundamentals and Access",
              "IP Connectivity and Services",
              "Security Fundamentals",
              "Network Automation and Programmability",
              "Hands-on Lab Experience",
              "Practice Exam Simulations"
            ].map((topic, index) => (
              <li key={index} className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                <span className="ml-3 text-gray-600 dark:text-gray-300">{topic}</span>
              </li>
            ))}
          </ul>

          <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Prerequisites</h3>
          <ul className="list-disc list-inside space-y-2 mb-8">
            {[
              "Basic computer knowledge",
              "Understanding of basic networking concepts"
            ].map((prereq, index) => (
              <li key={index} className="text-gray-600 dark:text-gray-300">{prereq}</li>
            ))}
          </ul>

          <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Career Outlook in Alabama</h3>
          <div className="space-y-6 mb-8">
            <div>
              <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Average Salaries</h4>
              <ul className="space-y-2">
                <li className="flex justify-between items-center bg-gray-50 dark:bg-gray-700 p-3 rounded">
                  <span className="text-gray-600 dark:text-gray-300">Entry Level Network Engineer</span>
                  <span className="font-semibold text-gray-900 dark:text-white">$55,000 - $65,000</span>
                </li>
                <li className="flex justify-between items-center bg-gray-50 dark:bg-gray-700 p-3 rounded">
                  <span className="text-gray-600 dark:text-gray-300">Network Administrator</span>
                  <span className="font-semibold text-gray-900 dark:text-white">$60,000 - $75,000</span>
                </li>
                <li className="flex justify-between items-center bg-gray-50 dark:bg-gray-700 p-3 rounded">
                  <span className="text-gray-600 dark:text-gray-300">Senior Network Engineer</span>
                  <span className="font-semibold text-gray-900 dark:text-white">$85,000 - $110,000</span>
                </li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Current Job Openings</h4>
              <div className="space-y-4">
                <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded">
                  <h5 className="font-semibold text-gray-900 dark:text-white">Network Engineer</h5>
                  <p className="text-gray-600 dark:text-gray-300 text-sm mb-2">ADTRAN - Huntsville, AL</p>
                  <p className="text-gray-600 dark:text-gray-300 mb-2">Design and implement enterprise networks, configure Cisco equipment, provide technical support.</p>
                  <p className="text-blue-600 dark:text-blue-400">$65,000 - $85,000</p>
                </div>
                
                <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded">
                  <h5 className="font-semibold text-gray-900 dark:text-white">Network Administrator</h5>
                  <p className="text-gray-600 dark:text-gray-300 text-sm mb-2">UAB Health System - Birmingham, AL</p>
                  <p className="text-gray-600 dark:text-gray-300 mb-2">Manage and maintain healthcare network infrastructure, implement security protocols.</p>
                  <p className="text-blue-600 dark:text-blue-400">$60,000 - $75,000</p>
                </div>
                
                <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded">
                  <h5 className="font-semibold text-gray-900 dark:text-white">IT Infrastructure Specialist</h5>
                  <p className="text-gray-600 dark:text-gray-300 text-sm mb-2">Regions Bank - Montgomery, AL</p>
                  <p className="text-gray-600 dark:text-gray-300 mb-2">Support network infrastructure, implement security measures, troubleshoot connectivity issues.</p>
                  <p className="text-blue-600 dark:text-blue-400">$55,000 - $70,000</p>
                </div>
              </div>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Industry Growth</h4>
              <p className="text-gray-600 dark:text-gray-300">
                Network engineering jobs in Alabama are projected to grow by 15% through 2025, with particularly strong demand in Huntsville's technology corridor and Birmingham's healthcare sector.
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-8">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Course Details</h2>
          
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Duration</h3>
              <p className="text-gray-600 dark:text-gray-300">96 Hours (6 Weeks)</p>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Schedule</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Morning Classes: Monday - Thursday, 8:00 AM - 12:00 PM<br />
                Evening Classes: Monday - Thursday, 6:00 PM - 10:00 PM
              </p>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Price</h3>
              <p className="text-3xl font-bold text-gray-900 dark:text-white mb-2">$4,995</p>
              <p className="text-gray-600 dark:text-gray-300">
                Includes all course materials, lab access, and practice exams
              </p>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Next Start Date</h3>
              <p className="text-gray-600 dark:text-gray-300">May 5, 2025</p>
            </div>

            <div className="border-t border-gray-200 dark:border-gray-700 pt-6">
              <div className="flex items-center gap-2 mb-4">
                <Calendar className="h-5 w-5 text-blue-600" />
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Available Start Dates</h3>
              </div>
              <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                <DayPicker
                  mode="multiple"
                  selected={startDates}
                  footer={footer}
                  fromMonth={new Date()}
                  disabled={[
                    { before: new Date() },
                    (date) => !startDates.some(d => 
                      d.getFullYear() === date.getFullYear() &&
                      d.getMonth() === date.getMonth() &&
                      d.getDate() === date.getDate()
                    )
                  ]}
                  modifiers={{
                    highlight: startDates
                  }}
                  modifiersStyles={{
                    highlight: {
                      backgroundColor: '#2563eb',
                      color: 'white',
                      borderRadius: '4px'
                    }
                  }}
                  styles={{
                    caption: { color: 'inherit' },
                    head: { color: 'inherit' },
                    day: { color: 'inherit' }
                  }}
                  className="mx-auto"
                />
              </div>
            </div>

            <form onSubmit={(e) => {
              e.preventDefault();
              navigate('/certification-training/ccna/register');
            }}>
              <button
                type="submit"
                className="w-full bg-blue-600 text-white py-4 px-6 rounded-lg text-lg font-semibold hover:bg-blue-700 transition-colors"
              >
                Enroll Now
              </button>
            </form>
          </div>
        </div>
      </div>
    </CertificationLayout>
  );
}

export default CCNACertification;