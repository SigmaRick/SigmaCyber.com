import React from 'react';
import { CheckCircle, Calendar } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import CertificationLayout from '../../components/CertificationLayout';
import { useEffect } from 'react';
import { DayPicker } from 'react-day-picker';
import 'react-day-picker/dist/style.css';

export default function CiscoCyberAssociateCertification() {
  const navigate = useNavigate();
  
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const startDates = [
    new Date(2025, 4, 5), // May 5, 2025
    new Date(2025, 6, 8), // July 8, 2025
    new Date(2025, 8, 15), // September 15, 2025
    new Date(2025, 10, 4), // November 4, 2025
  ];

  const footer = (
    <div className="mt-4 text-center text-gray-600 dark:text-gray-300">
      Available start dates are highlighted
    </div>
  );

  return (
    <CertificationLayout
      title="Cisco Certified Cybersecurity Associate"
      description="Entry-level cybersecurity certification providing foundational knowledge in network security, threat detection, and cybersecurity best practices."
      image="https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&q=80"
    >
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Course Overview</h2>
          <p className="text-gray-600 dark:text-gray-300 mb-8">The Cisco Certified Cybersecurity Associate program provides essential knowledge and skills needed to begin a career in cybersecurity. This comprehensive course provides hands-on experience with security tools and prepares you for the certification exam.</p>

          <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Key Topics</h3>
          <ul className="space-y-3 mb-8">
            {[
              "Security Concepts and Principles",
              "Network Foundation Protection",
              "Cryptography Fundamentals",
              "Access Control and Authentication",
              "Security Monitoring",
              "Security Analytics",
              "Incident Response",
              "Security Policies and Procedures"
            ].map((topic, index) => (
              <li key={index} className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                <span className="ml-3 text-gray-600 dark:text-gray-300">{topic}</span>
              </li>
            ))}
          </ul>

          <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Prerequisites</h3>
          <ul className="list-disc list-inside space-y-2 mb-8">
            <li className="text-gray-600 dark:text-gray-300">Basic IT knowledge</li>
            <li className="text-gray-600 dark:text-gray-300">Fundamental networking concepts</li>
            <li className="text-gray-600 dark:text-gray-300">Interest in cybersecurity</li>
          </ul>

          <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Career Outlook in Alabama</h3>
          <div className="space-y-6 mb-8">
            <div>
              <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Average Salaries</h4>
              <ul className="space-y-2">
                <li className="flex justify-between items-center bg-gray-50 dark:bg-gray-700 p-3 rounded">
                  <span className="text-gray-600 dark:text-gray-300">Entry Level Security Analyst</span>
                  <span className="font-semibold text-gray-900 dark:text-white">$65,000 - $75,000</span>
                </li>
                <li className="flex justify-between items-center bg-gray-50 dark:bg-gray-700 p-3 rounded">
                  <span className="text-gray-600 dark:text-gray-300">Cybersecurity Specialist</span>
                  <span className="font-semibold text-gray-900 dark:text-white">$70,000 - $90,000</span>
                </li>
                <li className="flex justify-between items-center bg-gray-50 dark:bg-gray-700 p-3 rounded">
                  <span className="text-gray-600 dark:text-gray-300">Information Security Analyst</span>
                  <span className="font-semibold text-gray-900 dark:text-white">$75,000 - $95,000</span>
                </li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Current Job Openings</h4>
              <div className="space-y-4">
                <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded">
                  <h5 className="font-semibold text-gray-900 dark:text-white">Security Operations Analyst</h5>
                  <p className="text-gray-600 dark:text-gray-300 text-sm mb-2">Redstone Arsenal - Huntsville, AL</p>
                  <p className="text-gray-600 dark:text-gray-300 mb-2">Monitor security systems, analyze threats, and implement security measures for defense contractors.</p>
                  <p className="text-blue-600 dark:text-blue-400">$70,000 - $85,000</p>
                </div>
                
                <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded">
                  <h5 className="font-semibold text-gray-900 dark:text-white">Information Security Specialist</h5>
                  <p className="text-gray-600 dark:text-gray-300 text-sm mb-2">Blue Cross Blue Shield - Birmingham, AL</p>
                  <p className="text-gray-600 dark:text-gray-300 mb-2">Protect healthcare data, implement security protocols, and maintain compliance with security standards.</p>
                  <p className="text-blue-600 dark:text-blue-400">$65,000 - $80,000</p>
                </div>
                
                <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded">
                  <h5 className="font-semibold text-gray-900 dark:text-white">Cybersecurity Analyst</h5>
                  <p className="text-gray-600 dark:text-gray-300 text-sm mb-2">Regions Bank - Montgomery, AL</p>
                  <p className="text-gray-600 dark:text-gray-300 mb-2">Monitor security incidents, conduct vulnerability assessments, and implement security best practices.</p>
                  <p className="text-blue-600 dark:text-blue-400">$68,000 - $82,000</p>
                </div>
              </div>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Industry Growth</h4>
              <p className="text-gray-600 dark:text-gray-300">
                Entry-level cybersecurity positions in Alabama are experiencing rapid growth, with a projected increase of 25% through 2025. The defense industry in Huntsville and financial sector in Birmingham are creating strong demand for certified cybersecurity professionals.
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-8">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Course Details</h2>
          
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Duration</h3>
              <p className="text-gray-600 dark:text-gray-300">96 Hours (6 Weeks)</p>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Schedule</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Morning Classes: Monday - Thursday, 8:00 AM - 12:00 PM<br />
                Evening Classes: Monday - Thursday, 6:00 PM - 10:00 PM
              </p>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Price</h3>
              <p className="text-3xl font-bold text-gray-900 dark:text-white mb-2">$4,995</p>
              <p className="text-gray-600 dark:text-gray-300">
                Includes course materials, virtual labs, and practice exams
              </p>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Next Start Date</h3>
              <p className="text-gray-600 dark:text-gray-300">June 16, 2025</p>
            </div>
          </div>

          <div className="border-t border-gray-200 dark:border-gray-700 pt-6">
            <div className="flex items-center gap-2 mb-4">
              <Calendar className="h-5 w-5 text-blue-600" />
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Available Start Dates</h3>
            </div>
            <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
              <DayPicker
                mode="multiple"
                selected={startDates}
                footer={footer}
                fromMonth={new Date()}
                disabled={[
                  { before: new Date() },
                  (date) => !startDates.some(d => 
                    d.getFullYear() === date.getFullYear() &&
                    d.getMonth() === date.getMonth() &&
                    d.getDate() === date.getDate()
                  )
                ]}
                modifiers={{
                  highlight: startDates
                }}
                modifiersStyles={{
                  highlight: {
                    backgroundColor: '#2563eb',
                    color: 'white',
                    borderRadius: '4px'
                  }
                }}
                styles={{
                  caption: { color: 'inherit' },
                  head: { color: 'inherit' },
                  day: { color: 'inherit' }
                }}
                className="mx-auto"
              />
            </div>
          </div>

          <form onSubmit={(e) => {
            e.preventDefault();
            navigate('/certification-training/cisco-certified-cybersecurity-associate/register');
          }}>
            <button
              type="submit"
              className="w-full bg-blue-600 text-white py-4 px-6 rounded-lg text-lg font-semibold hover:bg-blue-700 transition-colors"
            >
              Enroll Now
            </button>
          </form>
        </div>
      </div>
    </CertificationLayout>
  );
}