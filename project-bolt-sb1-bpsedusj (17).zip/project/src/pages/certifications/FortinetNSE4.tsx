import React from 'react';
import { CheckCircle, Calendar } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import CertificationLayout from '../../components/CertificationLayout';
import { useEffect } from 'react';
import { DayPicker } from 'react-day-picker';
import 'react-day-picker/dist/style.css';

export default function FortinetNSE4Certification() {
  const navigate = useNavigate();
  
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const startDates = [
    new Date(2025, 4, 5), // May 5, 2025
    new Date(2025, 6, 8), // July 8, 2025
    new Date(2025, 8, 15), // September 15, 2025
    new Date(2025, 10, 4), // November 4, 2025
  ];

  const footer = (
    <div className="mt-4 text-center text-gray-600 dark:text-gray-300">
      Available start dates are highlighted
    </div>
  );

  return (
    <CertificationLayout
      title="Fortinet NSE 4 Network Security Professional"
      description="Expert-led training for Fortinet NSE 4 certification, focusing on FortiGate network security platform and security infrastructure."
      image="https://images.unsplash.com/photo-1562813733-b31f71025d54?auto=format&fit=crop&q=80"
    >
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Course Overview</h2>
          <p className="text-gray-600 dark:text-gray-300 mb-8">
            The NSE 4 certification validates your ability to manage the day-to-day configuration, monitoring, and operation of FortiGate devices to support specific corporate network security policies.
          </p>

          <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Key Topics</h3>
          <ul className="space-y-3 mb-8">
            {[
              "FortiGate Security Features",
              "Firewall Policies and Authentication",
              "Network Security Best Practices",
              "SSL VPN and IPsec VPN Configuration",
              "Security Profiles and Web Filtering",
              "Threat Protection and Inspection",
              "High Availability Implementation",
              "Network Optimization Techniques"
            ].map((topic, index) => (
              <li key={index} className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                <span className="ml-3 text-gray-600 dark:text-gray-300">{topic}</span>
              </li>
            ))}
          </ul>

          <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Prerequisites</h3>
          <ul className="list-disc list-inside space-y-2 mb-8">
            {[
              "Network security fundamentals",
              "Basic networking knowledge",
              "Understanding of common network protocols"
            ].map((prereq, index) => (
              <li key={index} className="text-gray-600 dark:text-gray-300">{prereq}</li>
            ))}
          </ul>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-8">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Course Details</h2>
          
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Duration</h3>
              <p className="text-gray-600 dark:text-gray-300">96 Hours (6 Weeks)</p>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Schedule</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Evening classes: Monday & Wednesday, 7:00 PM - 9:30 PM<br />
                Lab sessions: Saturday, 9:00 AM - 12:00 PM
              </p>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Price</h3>
              <p className="text-3xl font-bold text-gray-900 dark:text-white mb-2">$4,995</p>
              <p className="text-gray-600 dark:text-gray-300">
                Includes FortiGate lab access, course materials, and NSE 4 exam voucher
              </p>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Next Start Date</h3>
              <p className="text-gray-600 dark:text-gray-300">April 8, 2024</p>
            </div>

            <div className="border-t border-gray-200 dark:border-gray-700 pt-6">
              <div className="flex items-center gap-2 mb-4">
                <Calendar className="h-5 w-5 text-blue-600" />
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Available Start Dates</h3>
              </div>
              <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                <DayPicker
                  mode="multiple"
                  selected={startDates}
                  footer={footer}
                  fromMonth={new Date()}
                  disabled={[
                    { before: new Date() },
                    (date) => !startDates.some(d => 
                      d.getFullYear() === date.getFullYear() &&
                      d.getMonth() === date.getMonth() &&
                      d.getDate() === date.getDate()
                    )
                  ]}
                  modifiers={{
                    highlight: startDates
                  }}
                  modifiersStyles={{
                    highlight: {
                      backgroundColor: '#2563eb',
                      color: 'white',
                      borderRadius: '4px'
                    }
                  }}
                  styles={{
                    caption: { color: 'inherit' },
                    head: { color: 'inherit' },
                    day: { color: 'inherit' }
                  }}
                  className="mx-auto"
                />
              </div>
            </div>

            <form onSubmit={(e) => {
              e.preventDefault();
              navigate('/certification-training/fortinet-nse-4-network-security-professional/register');
            }}>
              <button
                type="submit"
                className="w-full bg-blue-600 text-white py-4 px-6 rounded-lg text-lg font-semibold hover:bg-blue-700 transition-colors"
              >
                Enroll Now
              </button>
            </form>
          </div>
        </div>
      </div>
    </CertificationLayout>
  );
}