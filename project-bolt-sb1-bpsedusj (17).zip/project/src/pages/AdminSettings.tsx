import React, { useState, useEffect } from 'react';
import { Settings, Image } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { supabase } from '../utils/supabase';

interface Setting {
  id: string;
  key: string;
  value: string;
  created_at: string;
  updated_at: string;
}

export default function AdminSettings() {
  const [settings, setSettings] = useState<Setting[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [logoUrl, setLogoUrl] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'success' | 'error' | null>(null);

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('settings')
        .select('*');

      if (error) throw error;
      setSettings(data || []);

      const logoSetting = data?.find(s => s.key === 'logo_url');
      if (logoSetting) {
        setLogoUrl(logoSetting.value);
      }
    } catch (error) {
      console.error('Error fetching settings:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveLogo = async () => {
    setIsSaving(true);
    setSaveStatus(null);

    try {
      const { error } = await supabase
        .from('settings')
        .upsert({ 
          key: 'logo_url',
          value: logoUrl
        }, {
          onConflict: 'key'
        });

      if (error) throw error;
      setSaveStatus('success');
      fetchSettings();
    } catch (error) {
      console.error('Error saving logo:', error);
      setSaveStatus('error');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Header />
      <div className="h-32"></div>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">System Settings</h1>
            <p className="mt-2 text-gray-600 dark:text-gray-300">Configure website settings and appearance</p>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
          <div className="max-w-xl">
            <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6 flex items-center gap-2">
              <Settings className="h-5 w-5" />
              Logo Settings
            </h2>

            <div className="space-y-6">
              {/* Current Logo Preview */}
              {logoUrl && (
                <div className="p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                  <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Current Logo</h3>
                  <img
                    src={logoUrl}
                    alt="Current logo"
                    className="max-w-xs h-auto rounded"
                  />
                </div>
              )}

              {/* Logo URL Input */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Logo URL
                </label>
                <div className="flex gap-4">
                  <input
                    type="url"
                    value={logoUrl}
                    onChange={(e) => setLogoUrl(e.target.value)}
                    placeholder="Enter logo URL"
                    className="flex-1 px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                  />
                  <button
                    onClick={handleSaveLogo}
                    disabled={isSaving}
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                  >
                    <Image className="h-5 w-5" />
                    {isSaving ? 'Saving...' : 'Save Logo'}
                  </button>
                </div>
                {saveStatus === 'success' && (
                  <p className="mt-2 text-sm text-green-600 dark:text-green-400">Logo updated successfully!</p>
                )}
                {saveStatus === 'error' && (
                  <p className="mt-2 text-sm text-red-600 dark:text-red-400">Error updating logo. Please try again.</p>
                )}
              </div>

              <div className="bg-blue-50 dark:bg-blue-900/30 p-4 rounded-lg">
                <h4 className="text-sm font-medium text-blue-900 dark:text-blue-100 mb-2">Logo Requirements</h4>
                <ul className="text-sm text-blue-800 dark:text-blue-200 space-y-1">
                  <li>• Use a direct image URL (https://)</li>
                  <li>• Recommended size: 200x50 pixels</li>
                  <li>• Supported formats: PNG, SVG (with transparency)</li>
                  <li>• Maximum file size: 1MB</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}