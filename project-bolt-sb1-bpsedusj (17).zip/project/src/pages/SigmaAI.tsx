import React from 'react';
import { Brain, MessageSquare, Calendar, Phone, Bot, Code, Sparkles, Zap, Shield, CheckCircle, MapPin, Mail } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import ContactForm from '../components/ContactForm';

export default function SigmaAI() {
  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 pt-48">
      <Header />

      <div className="relative overflow-hidden bg-gradient-to-r from-blue-600 to-blue-800 py-24 mb-16 mt-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-3xl mx-auto">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              AI-Powered Website Solutions
            </h1>
            <p className="text-xl text-blue-100 max-w-3xl mx-auto mb-8">
              We build intelligent websites that leverage AI to drive engagement, automate tasks, and boost conversions
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <div className="bg-white/10 px-6 py-2 rounded-full text-white">Intelligent Design</div>
              <div className="bg-white/10 px-6 py-2 rounded-full text-white">Smart Automation</div>
              <div className="bg-white/10 px-6 py-2 rounded-full text-white">24/7 AI Support</div>
            </div>
          </div>
        </div>
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-gray-50 dark:to-gray-900" />
      </div>

      <div className="py-24 bg-white dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              AI-First Website Development
            </h2>
            <p className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              We build websites that don't just look great - they think, learn, and adapt to your business needs
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center mb-24">
            <div>
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
                Intelligent Website Features
              </h3>
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="p-2 bg-blue-100 dark:bg-blue-900 rounded-lg">
                    <Brain className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 dark:text-white">Smart Content Management</h4>
                    <p className="text-gray-600 dark:text-gray-300">
                      AI-powered content generation and optimization that keeps your site fresh and engaging
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="p-2 bg-green-100 dark:bg-green-900 rounded-lg">
                    <Bot className="h-6 w-6 text-green-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 dark:text-white">Automated Customer Service</h4>
                    <p className="text-gray-600 dark:text-gray-300">
                      24/7 AI support that handles inquiries, books appointments, and assists customers
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="p-2 bg-purple-100 dark:bg-purple-900 rounded-lg">
                    <Zap className="h-6 w-6 text-purple-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 dark:text-white">Dynamic Personalization</h4>
                    <p className="text-gray-600 dark:text-gray-300">
                      Websites that adapt to each visitor's preferences and behavior
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80"
                alt="AI Website Development"
                className="rounded-xl shadow-2xl"
              />
              <div className="absolute -bottom-6 -right-6 bg-blue-600 text-white p-6 rounded-xl shadow-xl">
                <p className="text-2xl font-bold">100%</p>
                <p className="text-sm">AI-Powered</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8">
              <div className="flex items-center gap-4 mb-6">
                <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-lg">
                  <MessageSquare className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white">AI Chat Support</h3>
              </div>
              <p className="text-gray-600 dark:text-gray-300 mb-6">
                24/7 intelligent customer support powered by advanced language models. Handle inquiries, provide product information, and assist with bookings automatically.
              </p>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                  <span className="ml-3 text-gray-600 dark:text-gray-300">Natural language understanding</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                  <span className="ml-3 text-gray-600 dark:text-gray-300">Multi-language support</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                  <span className="ml-3 text-gray-600 dark:text-gray-300">Seamless handoff to human agents</span>
                </li>
              </ul>
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8">
              <div className="flex items-center gap-4 mb-6">
                <div className="p-3 bg-purple-100 dark:bg-purple-900 rounded-lg">
                  <Calendar className="h-8 w-8 text-purple-600" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white">Smart Scheduling</h3>
              </div>
              <p className="text-gray-600 dark:text-gray-300 mb-6">
                AI-powered scheduling system that intelligently manages appointments, considers availability, and optimizes time slots for maximum efficiency.
              </p>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                  <span className="ml-3 text-gray-600 dark:text-gray-300">Automated scheduling</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                  <span className="ml-3 text-gray-600 dark:text-gray-300">Calendar integration</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                  <span className="ml-3 text-gray-600 dark:text-gray-300">Smart conflict resolution</span>
                </li>
              </ul>
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8">
              <div className="flex items-center gap-4 mb-6">
                <div className="p-3 bg-green-100 dark:bg-green-900 rounded-lg">
                  <Phone className="h-8 w-8 text-green-600" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white">Voice Sales AI</h3>
              </div>
              <p className="text-gray-600 dark:text-gray-300 mb-6">
                Voice-enabled sales assistant that can handle inquiries, provide product information, and process orders through natural conversation.
              </p>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                  <span className="ml-3 text-gray-600 dark:text-gray-300">Natural voice interaction</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                  <span className="ml-3 text-gray-600 dark:text-gray-300">Product recommendations</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                  <span className="ml-3 text-gray-600 dark:text-gray-300">Secure payment processing</span>
                </li>
              </ul>
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8">
              <div className="flex items-center gap-4 mb-6">
                <div className="p-3 bg-red-100 dark:bg-red-900 rounded-lg">
                  <Sparkles className="h-8 w-8 text-red-600" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white">Content AI</h3>
              </div>
              <p className="text-gray-600 dark:text-gray-300 mb-6">
                Automated content generation and optimization for your website. Create engaging, SEO-friendly content that resonates with your audience.
              </p>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                  <span className="ml-3 text-gray-600 dark:text-gray-300">SEO optimization</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                  <span className="ml-3 text-gray-600 dark:text-gray-300">Automated blog posts</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                  <span className="ml-3 text-gray-600 dark:text-gray-300">Content personalization</span>
                </li>
              </ul>
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8">
              <div className="flex items-center gap-4 mb-6">
                <div className="p-3 bg-yellow-100 dark:bg-yellow-900 rounded-lg">
                  <Bot className="h-8 w-8 text-yellow-600" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white">Smart Personalization</h3>
              </div>
              <p className="text-gray-600 dark:text-gray-300 mb-6">
                AI-driven personalization that adapts your website content and experience based on user behavior and preferences.
              </p>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                  <span className="ml-3 text-gray-600 dark:text-gray-300">Dynamic content</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                  <span className="ml-3 text-gray-600 dark:text-gray-300">Behavioral analysis</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                  <span className="ml-3 text-gray-600 dark:text-gray-300">A/B testing automation</span>
                </li>
              </ul>
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8">
              <div className="flex items-center gap-4 mb-6">
                <div className="p-3 bg-indigo-100 dark:bg-indigo-900 rounded-lg">
                  <Zap className="h-8 w-8 text-indigo-600" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white">AI Analytics</h3>
              </div>
              <p className="text-gray-600 dark:text-gray-300 mb-6">
                Advanced analytics and insights powered by AI. Understand user behavior, predict trends, and make data-driven decisions.
              </p>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                  <span className="ml-3 text-gray-600 dark:text-gray-300">Predictive analytics</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                  <span className="ml-3 text-gray-600 dark:text-gray-300">User behavior tracking</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                  <span className="ml-3 text-gray-600 dark:text-gray-300">Conversion optimization</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-gray-50 dark:bg-gray-800 py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              Seamless Integration
            </h2>
            <p className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              Our AI solutions integrate smoothly with your existing website and business systems
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="flex justify-center mb-4">
                <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-lg">
                  <Code className="h-8 w-8 text-blue-600" />
                </div>
              </div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Easy Setup</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Simple integration process with your existing website and systems
              </p>
            </div>

            <div className="text-center">
              <div className="flex justify-center mb-4">
                <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-lg">
                  <Shield className="h-8 w-8 text-blue-600" />
                </div>
              </div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Secure & Reliable</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Enterprise-grade security and 99.9% uptime guarantee
              </p>
            </div>

            <div className="text-center">
              <div className="flex justify-center mb-4">
                <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-lg">
                  <Brain className="h-8 w-8 text-blue-600" />
                </div>
              </div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Always Learning</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Continuous improvement through machine learning
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-blue-600 py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-6">
            Ready for an AI-Powered Website?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Let's build you a website that thinks, learns, and grows with your business
          </p>
          <a
            href="#consultation"
            className="inline-block bg-white text-blue-600 px-8 py-3 rounded-lg text-lg font-semibold hover:bg-blue-50 transition-colors"
          >
            Schedule Consultation
          </a>
        </div>
      </div>

      <div id="consultation" className="py-24 bg-gray-50 dark:bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-6">Get Started</h2>
              <p className="text-lg text-gray-600 dark:text-gray-300 mb-8">
                Schedule a consultation to discuss how we can transform your website with AI technology.
              </p>
              <dl className="space-y-6">
                <div className="flex">
                  <div className="flex-shrink-0">
                    <MapPin className="h-6 w-6 text-blue-600" />
                  </div>
                  <div className="ml-3">
                    <dt className="text-lg font-medium text-gray-900 dark:text-white">Address</dt>
                    <dd className="mt-1 text-gray-500 dark:text-gray-300">710 7th Street Clanton, AL 35045</dd>
                  </div>
                </div>
                <div className="flex">
                  <div className="flex-shrink-0">
                    <Phone className="h-6 w-6 text-blue-600" />
                  </div>
                  <div className="ml-3">
                    <dt className="text-lg font-medium text-gray-900 dark:text-white">Phone</dt>
                    <dd className="mt-1 text-gray-500 dark:text-gray-300">205.415.9470</dd>
                  </div>
                </div>
                <div className="flex">
                  <div className="flex-shrink-0">
                    <Mail className="h-6 w-6 text-blue-600" />
                  </div>
                  <div className="ml-3">
                    <dt className="text-lg font-medium text-gray-900 dark:text-white">Email</dt>
                    <dd className="mt-1 text-gray-500 dark:text-gray-300">cyberexperts@sigmacybercorp.com</dd>
                  </div>
                </div>
              </dl>
            </div>
            <div className="bg-white dark:bg-gray-700 rounded-lg shadow-lg p-8">
              <ContactForm />
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}