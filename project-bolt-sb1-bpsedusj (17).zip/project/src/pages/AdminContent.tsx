import React, { useState, useEffect } from 'react';
import { FileText, Plus, Search, Edit, Trash2, Image } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { supabase } from '../utils/supabase';

interface PageSection {
  page: string;
  sections: {
    name: string;
    blocks: ContentBlock[];
  }[];
}

interface ContentBlock {
  id: string;
  key: string;
  title: string;
  content: string;
  image_url: string | null;
  page: string;
  section: string;
  created_at: string;
  updated_at: string;
}

export default function AdminContent() {
  const [contents, setContents] = useState<ContentBlock[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedPage, setSelectedPage] = useState<string>('home');
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingContent, setEditingContent] = useState<ContentBlock | null>(null);
  const [formData, setFormData] = useState({
    key: '',
    title: '',
    content: '',
    image_url: '',
    page: '',
    section: ''
  });

  useEffect(() => {
    fetchContent();
  }, []);

  const fetchContent = async () => {
    try {
      const { data, error } = await supabase
        .from('content_blocks')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setContents(data || []);
    } catch (error) {
      console.error('Error fetching content:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingContent) {
        const { error } = await supabase
          .from('content_blocks')
          .update(formData)
          .eq('id', editingContent.id);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('content_blocks')
          .insert([formData]);
        if (error) throw error;
      }
      
      fetchContent();
      setShowAddModal(false);
      setEditingContent(null);
      setFormData({
        key: '',
        title: '',
        content: '',
        image_url: '',
        page: '',
        section: ''
      });
    } catch (error) {
      console.error('Error saving content:', error);
    }
  };

  const handleEdit = (content: ContentBlock) => {
    setEditingContent(content);
    setFormData({
      key: content.key,
      title: content.title,
      content: content.content,
      image_url: content.image_url || '',
      page: content.page,
      section: content.section
    });
    setShowAddModal(true);
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this content block?')) return;
    
    try {
      const { error } = await supabase
        .from('content_blocks')
        .delete()
        .eq('id', id);
      
      if (error) throw error;
      fetchContent();
    } catch (error) {
      console.error('Error deleting content:', error);
    }
  };

  // Organize content by page and section
  const organizedContent: PageSection[] = React.useMemo(() => {
    const pages = [...new Set(contents.map(c => c.page))];
    return pages.map(page => {
      const pageContents = contents.filter(c => c.page === page);
      const sections = [...new Set(pageContents.map(c => c.section))];
      return {
        page,
        sections: sections.map(section => ({
          name: section,
          blocks: pageContents.filter(c => c.section === section)
        }))
      };
    });
  }, [contents]);

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Header />
      <div className="h-32"></div>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Content Management</h1>
            <p className="mt-2 text-gray-600 dark:text-gray-300">Manage website content and images</p>
          </div>
          <button
            onClick={() => {
              setEditingContent(null);
              setFormData({
                key: '',
                title: '',
                content: '',
                image_url: '',
                page: '',
                section: ''
              });
              setShowAddModal(true);
            }}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2"
          >
            <Plus className="h-5 w-5" />
            Add Content
          </button>
        </div>

        {/* Page Navigation */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 mb-8">
          <div className="flex gap-4">
            {organizedContent.map((pageData) => (
              <button
                key={pageData.page}
                onClick={() => setSelectedPage(pageData.page)}
                className={`px-4 py-2 rounded-lg font-medium ${
                  selectedPage === pageData.page
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                }`}
              >
                {pageData.page.charAt(0).toUpperCase() + pageData.page.slice(1)}
              </button>
            ))}
          </div>
        </div>

        {/* Content Sections */}
        <div className="space-y-8">
          {isLoading ? (
            <div className="col-span-full text-center text-gray-500 dark:text-gray-400">
              Loading content...
            </div>
          ) : (
            organizedContent
              .find(p => p.page === selectedPage)
              ?.sections.map((section) => (
                <div key={section.name} className="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                  <div className="p-6">
                    <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-6">
                      {section.name.charAt(0).toUpperCase() + section.name.slice(1)}
                    </h3>
                    <div className="space-y-6">
                      {section.blocks.map((content) => (
                        <div key={content.id} className="border-b border-gray-200 dark:border-gray-700 pb-6 last:border-0 last:pb-0">
                          <div className="flex justify-between items-start mb-4">
                            <div>
                              <h4 className="text-lg font-semibold text-gray-900 dark:text-white">{content.title}</h4>
                              <p className="text-sm text-gray-500 dark:text-gray-400">{content.key}</p>
                            </div>
                            <div className="flex gap-2">
                              <button
                                onClick={() => handleEdit(content)}
                                className="text-blue-600 hover:text-blue-900 dark:hover:text-blue-400"
                              >
                                <Edit className="h-5 w-5" />
                              </button>
                              <button
                                onClick={() => handleDelete(content.id)}
                                className="text-red-600 hover:text-red-900 dark:hover:text-red-400"
                              >
                                <Trash2 className="h-5 w-5" />
                              </button>
                            </div>
                          </div>
                          <div className="prose dark:prose-invert max-w-none">
                            {content.content && (
                              <div className="bg-gray-50 dark:bg-gray-700 rounded p-4 mb-4">
                                <p className="text-gray-900 dark:text-gray-100 whitespace-pre-wrap">{content.content}</p>
                              </div>
                            )}
                            {content.image_url && (
                              <div className="mt-4">
                                <img
                                  src={content.image_url}
                                  alt={content.title}
                                  className="max-w-sm rounded-lg"
                                />
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ))
          )}
        </div>
      </main>

      {/* Add/Edit Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-2xl w-full p-6">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
              {editingContent ? 'Edit Content' : 'Add New Content'}
            </h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Key
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.key}
                    onChange={(e) => setFormData({ ...formData, key: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Title
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Content
                </label>
                <textarea
                  required
                  rows={6}
                  value={formData.content}
                  onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Image URL
                </label>
                <input
                  type="url"
                  value={formData.image_url}
                  onChange={(e) => setFormData({ ...formData, image_url: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Page
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.page}
                    onChange={(e) => setFormData({ ...formData, page: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Section
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.section}
                    onChange={(e) => setFormData({ ...formData, section: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                  />
                </div>
              </div>
              <div className="flex justify-end gap-4 mt-6">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  {editingContent ? 'Save Changes' : 'Add Content'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <Footer />
    </div>
  );
}