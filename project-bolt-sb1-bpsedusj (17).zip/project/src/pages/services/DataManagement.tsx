import React from 'react';
import { useEffect } from 'react';
import { Database, CheckCircle } from 'lucide-react';
import ServiceLayout from '../../components/ServiceLayout';
import Header from '../../components/Header';
import { sendEmail } from '../../utils/email';

export default function DataManagement() {
  const [status, setStatus] = React.useState<'idle' | 'success' | 'error'>('idle');

  return (
    <ServiceLayout
      title="Data Management Services"
      description="Comprehensive data solutions and backup services for enterprise environments"
      image="https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80"
      icon={Database}
    >
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Service Overview</h2>
          <p className="text-gray-600 dark:text-gray-300 mb-8">
            Our data management services ensure your critical business data is properly stored, protected, and accessible. We provide comprehensive solutions for data backup, recovery, and compliance management.
          </p>

          <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Key Features</h3>
          <ul className="space-y-4 mb-8">
            {[
              "Automated backup solutions",
              "Data recovery and business continuity",
              "Database management and optimization",
              "Data security and encryption",
              "Compliance management",
              "Data migration services",
              "Storage optimization",
              "Data archival solutions",
              "Database performance tuning",
              "24/7 monitoring and support"
            ].map((feature, index) => (
              <li key={index} className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                <span className="ml-3 text-gray-600 dark:text-gray-300">{feature}</span>
              </li>
            ))}
          </ul>

          <div className="bg-blue-50 dark:bg-blue-900/30 p-6 rounded-lg mb-8">
            <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-3">Benefits</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                <span className="ml-3 text-gray-600 dark:text-gray-300">Enhanced data protection and security</span>
              </li>
              <li className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                <span className="ml-3 text-gray-600 dark:text-gray-300">Improved data accessibility and performance</span>
              </li>
              <li className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                <span className="ml-3 text-gray-600 dark:text-gray-300">Regulatory compliance assurance</span>
              </li>
              <li className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                <span className="ml-3 text-gray-600 dark:text-gray-300">Reduced risk of data loss</span>
              </li>
            </ul>
          </div>
        </div>

        <div>
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-8 sticky top-8">
            <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Get Started</h3>
            <form className="space-y-6" onSubmit={async (e) => {
              e.preventDefault();
              const formData = new FormData(e.currentTarget);
              const data = {
                from_name: formData.get('name'),
                from_email: formData.get('email'),
                phone: formData.get('phone'),
                company: formData.get('company'),
                inquiry_type: 'support',
                message: `
Service: Data Management Services
Name: ${formData.get('name')}
Email: ${formData.get('email')}
Phone: ${formData.get('phone')}
Company: ${formData.get('company')}

Message:
${formData.get('message')}
                `.trim()
              };
              
              try {
                await sendEmail(data, "template_urxs95c");
                setStatus('success');
                if (e.currentTarget) {
                  e.currentTarget.reset();
                }
              } catch (error) {
                setStatus('error');
                console.error('Error sending email:', error);
              }
            }}>
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Name</label>
                <input
                  type="text"
                  name="name"
                  id="name"
                  required
                  className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                />
              </div>
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Email</label>
                <input
                  type="email"
                  name="email"
                  id="email"
                  required
                  className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                />
              </div>
              <div>
                <label htmlFor="phone" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Phone</label>
                <input
                  type="tel"
                  name="phone"
                  id="phone"
                  required
                  className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                />
              </div>
              <div>
                <label htmlFor="company" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Company</label>
                <input
                  type="text"
                  name="company"
                  id="company"
                  required
                  className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                />
              </div>
              <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Message</label>
                <textarea
                  name="message"
                  id="message"
                  rows={4}
                  required
                  className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                  placeholder="Tell us about your data management needs..."
                />
              </div>
              {status === 'success' && (
                <div className="p-4 bg-green-50 dark:bg-green-900/30 text-green-800 dark:text-green-200 rounded-md">
                  Message sent successfully! We'll get back to you soon.
                </div>
              )}
              <button
                type="submit"
                className="w-full bg-blue-600 text-white py-3 px-4 rounded-md hover:bg-blue-700 transition-colors"
              >
                Request Consultation
              </button>
            </form>

            <div className="mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
              <p className="text-gray-600 dark:text-gray-300 text-sm">
                Or call us directly at{' '}
                <a href="tel:205.415.9470" className="text-blue-600 hover:text-blue-700 font-medium">
                  205.415.9470
                </a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </ServiceLayout>
  );
}