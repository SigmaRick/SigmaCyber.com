import React from 'react';
import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Network, CheckCircle } from 'lucide-react';
import ServiceLayout from '../../components/ServiceLayout';
import { sendEmail } from '../../utils/email';
import Header from '../../components/Header';

export default function NetworkInfrastructure() {
  const [status, setStatus] = React.useState<'idle' | 'success' | 'error'>('idle');

  return (
    <ServiceLayout
      title="Network Infrastructure Services"
      description="Complete network management and optimization services for enterprise environments"
      image="https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&q=80"
      icon={Network}
    >
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div>
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Service Overview</h2>
            <p className="text-gray-600 dark:text-gray-300 mb-8">
              Our comprehensive network infrastructure services ensure your organization's network runs at peak performance. We provide end-to-end solutions from design and implementation to ongoing maintenance and optimization.
            </p>

            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Key Features</h3>
            <ul className="space-y-4 mb-8">
              {[
                "24/7 network monitoring and alerting",
                "Network design and implementation",
                "Performance optimization and troubleshooting",
                "Network security management",
                "Bandwidth optimization and QoS",
                "Infrastructure documentation",
                "Capacity planning",
                "Network redundancy and failover",
                "Wireless network solutions",
                "VPN and remote access setup"
              ].map((feature, index) => (
                <li key={index} className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                  <span className="ml-3 text-gray-600 dark:text-gray-300">{feature}</span>
                </li>
              ))}
            </ul>

            <div className="bg-blue-50 dark:bg-blue-900/30 p-6 rounded-lg mb-8">
              <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-3">Why Choose Our Network Services?</h3>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                  <span className="ml-3 text-gray-600 dark:text-gray-300">Certified network engineers available 24/7</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                  <span className="ml-3 text-gray-600 dark:text-gray-300">Proactive monitoring and maintenance</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                  <span className="ml-3 text-gray-600 dark:text-gray-300">Enterprise-grade tools and solutions</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                  <span className="ml-3 text-gray-600 dark:text-gray-300">Customized solutions for your business needs</span>
                </li>
              </ul>
            </div>
          </div>

          <div>
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-8 sticky top-8">
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Get Started</h3>
              <form className="space-y-6" onSubmit={async (e) => {
                e.preventDefault();
                const formData = new FormData(e.currentTarget);
                const data = {
                  from_name: formData.get('name'),
                  from_email: formData.get('email'),
                  phone: formData.get('phone'),
                  company: formData.get('company'),
                  inquiry_type: 'support',
                  message: `
Service: Network Infrastructure
Name: ${formData.get('name')}
Email: ${formData.get('email')}
Phone: ${formData.get('phone')}
Company: ${formData.get('company')}

Message:
${formData.get('message')}
                  `.trim()
                };
                
                await sendEmail(data, "template_urxs95c");
                setStatus('success');
                if (e.currentTarget) {
                  e.currentTarget.reset();
                }
              }}>
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Name</label>
                  <input
                    type="text"
                    name="name"
                    id="name"
                    required
                    className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Email</label>
                  <input
                    type="email"
                    name="email"
                    id="email"
                    required
                    className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                  />
                </div>
                <div>
                  <label htmlFor="phone" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Phone</label>
                  <input
                    type="tel"
                    name="phone"
                    id="phone"
                    required
                    className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                  />
                </div>
                <div>
                  <label htmlFor="company" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Company</label>
                  <input
                    type="text"
                    name="company"
                    id="company"
                    required
                    className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                  />
                </div>
                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Message</label>
                  <textarea
                    name="message"
                    id="message"
                    rows={4}
                    required
                    className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                    placeholder="Tell us about your network infrastructure needs..."
                  />
                </div>
                {status === 'success' && (
                  <div className="p-4 bg-green-50 dark:bg-green-900/30 text-green-800 dark:text-green-200 rounded-md">
                    Message sent successfully! We'll get back to you soon.
                  </div>
                )}
                <button
                  type="submit"
                  className="w-full bg-blue-600 text-white py-3 px-4 rounded-md hover:bg-blue-700 transition-colors"
                >
                  Request Consultation
                </button>
              </form>

              <div className="mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
                <p className="text-gray-600 dark:text-gray-300 text-sm">
                  Or call us directly at{' '}
                  <a href="tel:205.415.9470" className="text-blue-600 hover:text-blue-700 font-medium">
                    205.415.9470
                  </a>
                </p>
              </div>
            </div>
          </div>
        </div>
    </ServiceLayout>
  );
}