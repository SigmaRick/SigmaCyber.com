import React from 'react';
import { useEffect } from 'react';
import { Shield, Lock, AlertTriangle, Search, CheckCircle, Server, Network, FileText, BarChart, Bot } from 'lucide-react';
import Header from '../../components/Header';
import Footer from '../../components/Footer';
import ContactForm from '../../components/ContactForm';

interface StatCardProps {
  title: string;
  value: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
}

function StatCard({ title, value, description, icon: Icon }: StatCardProps) {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg">
      <div className="flex items-center gap-4 mb-4">
        <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-lg">
          <Icon className="h-6 w-6 text-blue-600" />
        </div>
        <div>
          <h3 className="text-xl font-bold text-gray-900 dark:text-white">{title}</h3>
          <p className="text-3xl font-bold text-blue-600">{value}</p>
        </div>
      </div>
      <p className="text-gray-600 dark:text-gray-300">{description}</p>
    </div>
  );
}

interface ServiceCardProps {
  title: string;
  description: string;
  features: string[];
  icon: React.ComponentType<{ className?: string }>;
}

function ServiceCard({ title, description, features, icon: Icon }: ServiceCardProps) {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl p-8 shadow-lg">
      <div className="flex items-center gap-4 mb-6">
        <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-lg">
          <Icon className="h-8 w-8 text-blue-600" />
        </div>
        <h3 className="text-2xl font-bold text-gray-900 dark:text-white">{title}</h3>
      </div>
      <p className="text-lg text-gray-600 dark:text-gray-300 mb-6">{description}</p>
      <ul className="space-y-3">
        {features.map((feature, index) => (
          <li key={index} className="flex items-start">
            <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
            <span className="ml-3 text-gray-600 dark:text-gray-300">{feature}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default function EnterpriseCybersecurity() {
  useEffect(() => {
    window.scrollTo(0, 0); 
  }, []);

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Header />
      <div className="h-32"></div>
      
      <div className="relative overflow-hidden bg-gradient-to-r from-blue-600 to-blue-800 py-24 mb-16"> 
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-3xl mx-auto">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Enterprise-Grade Cybersecurity Solutions
            </h1>
            <p className="text-xl text-blue-100 mb-8">
              Protect your business with advanced threat detection, 24/7 monitoring, and expert security architecture
            </p>
          </div>
        </div>
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-gray-50 dark:to-gray-900" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <div className="relative h-[400px] rounded-xl overflow-hidden mb-16">
            <img
              src="https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80"
              alt="Cybersecurity Operations Center"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-gray-900/60 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-8 text-white text-left">
              <h2 className="text-3xl font-extrabold mb-2">Advanced Security Operations</h2>
              <p className="text-xl font-bold text-white">24/7 monitoring and threat detection by certified security experts</p>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="py-24 bg-white dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"> 
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              Cybersecurity by the Numbers
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300">
              Our proven track record in protecting enterprise environments
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <StatCard
              title="Threats Blocked"
              value="10M+"
              description="Advanced threats blocked monthly across our client networks"
              icon={Shield}
            />
            <StatCard
              title="Response Time"
              value="< 15min"
              description="Average incident response time for critical alerts"
              icon={AlertTriangle}
            />
            <StatCard
              title="Protected Assets"
              value="500K+"
              description="Endpoints and servers under our protection"
              icon={Server}
            />
            <StatCard
              title="Success Rate"
              value="99.9%"
              description="Threat detection and prevention success rate"
              icon={CheckCircle}
            />
          </div>
        </div>
      </div>

      {/* Services Section */}
      <div id="services" className="py-24 bg-gray-50 dark:bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              Comprehensive Security Services
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300">
              End-to-end protection for your digital assets
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <ServiceCard
              title="Security Assessment & Auditing"
              description="Comprehensive evaluation of your security posture with actionable recommendations."
              icon={Search}
              features={[
                "Vulnerability assessments",
                "Penetration testing",
                "Security architecture review",
                "Compliance gap analysis",
                "Risk assessment"
              ]}
            />
            <ServiceCard
              title="Advanced Firewall Protection"
              description="Next-generation firewall solutions with intelligent threat prevention."
              icon={Shield}
              features={[
                "Application-aware filtering",
                "Intrusion prevention",
                "SSL inspection",
                "Zero-day threat protection",
                "Automated response actions"
              ]}
            />
            <ServiceCard
              title="24/7 Security Monitoring"
              description="Round-the-clock monitoring and incident response by security experts."
              icon={BarChart}
              features={[
                "Real-time threat detection",
                "Security incident response",
                "Log analysis and correlation",
                "Compliance monitoring",
                "Performance analytics"
              ]}
            />
            <ServiceCard
              title="AI-Powered Security"
              description="Advanced machine learning algorithms for predictive threat detection."
              icon={Bot}
              features={[
                "Behavioral analysis",
                "Anomaly detection",
                "Automated threat hunting",
                "Pattern recognition",
                "Predictive analytics"
              ]}
            />
          </div>
        </div>
      </div>

      {/* Security Dashboard Preview */}
      <div className="py-24 bg-gradient-to-r from-blue-50 to-transparent dark:from-blue-900/20 dark:to-transparent">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-6">
                Advanced Security Analytics
              </h2>
              <p className="text-xl text-gray-600 dark:text-gray-300 mb-8">
                Get real-time insights into your security posture with our advanced analytics dashboard.
              </p>
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="p-2 bg-blue-100 dark:bg-blue-900 rounded-lg">
                    <BarChart className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-gray-900 dark:text-white">Real-time Monitoring</h4>
                    <p className="text-gray-600 dark:text-gray-300">
                      Monitor security events and threats in real-time across your entire infrastructure.
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="p-2 bg-blue-100 dark:bg-blue-900 rounded-lg">
                    <FileText className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-gray-900 dark:text-white">Detailed Reporting</h4>
                    <p className="text-gray-600 dark:text-gray-300">
                      Generate comprehensive security reports and compliance documentation.
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="p-2 bg-blue-100 dark:bg-blue-900 rounded-lg">
                    <Network className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-gray-900 dark:text-white">Network Visibility</h4>
                    <p className="text-gray-600 dark:text-gray-300">
                      Complete visibility into network traffic and security events.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&q=80"
                alt="Security Dashboard"
                className="rounded-xl shadow-2xl"
              />
              <div className="absolute -bottom-6 -right-6 bg-blue-600 text-white p-6 rounded-xl shadow-xl">
                <p className="text-2xl font-bold">24/7</p>
                <p className="text-sm">Monitoring</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Contact Section */}
      <div id="contact" className="py-24 bg-white dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-6">
                Get Started with Enterprise Security
              </h2>
              <p className="text-xl text-gray-600 dark:text-gray-300 mb-8">
                Contact us to schedule a security assessment and learn how we can protect your business.
              </p>
              <div className="bg-white dark:bg-gray-700 rounded-xl p-6 mb-8">
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Why Choose Us?</h3>
                <ul className="space-y-4">
                  <li className="flex items-start">
                    <CheckCircle className="h-6 w-6 text-green-500 mt-1 flex-shrink-0" />
                    <span className="ml-3 text-gray-600 dark:text-gray-300">
                      25+ years of enterprise security experience
                    </span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-6 w-6 text-green-500 mt-1 flex-shrink-0" />
                    <span className="ml-3 text-gray-600 dark:text-gray-300">
                      Certified security experts available 24/7
                    </span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-6 w-6 text-green-500 mt-1 flex-shrink-0" />
                    <span className="ml-3 text-gray-600 dark:text-gray-300">
                      Advanced AI-powered threat detection
                    </span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-6 w-6 text-green-500 mt-1 flex-shrink-0" />
                    <span className="ml-3 text-gray-600 dark:text-gray-300">
                      Customized security solutions for your business
                    </span>
                  </li>
                </ul>
              </div>
            </div>
            <div className="bg-white dark:bg-gray-700 rounded-xl shadow-lg p-8">
              <ContactForm />
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}