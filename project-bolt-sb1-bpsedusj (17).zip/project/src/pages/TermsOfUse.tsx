import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';

export default function TermsOfUse() {
  return (
    <div className="min-h-screen bg-white dark:bg-gray-900">
      <Header />
      <div className="h-32"></div>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-8">Terms of Use</h1>
        
        <div className="prose dark:prose-invert max-w-none text-gray-900 dark:text-gray-200">
          <p>Last updated: January 1, 2025</p>

          <h2>1. Acceptance of Terms</h2>
          <p>By accessing and using this website, you accept and agree to be bound by the terms and provision of this agreement.</p>

          <h2>2. Services Description</h2>
          <p>Sigma Cyber provides IT certification training and professional support services. We reserve the right to modify, suspend or discontinue any aspect of our services at any time.</p>

          <h2>3. Registration and Course Enrollment</h2>
          <p>Users must provide accurate and complete information when registering for courses. Payment is required to confirm enrollment in any certification program.</p>

          <h2>4. Intellectual Property Rights</h2>
          <p>All content on this website, including but not limited to text, graphics, logos, and images, is the property of Sigma Cyber and protected by intellectual property laws.</p>

          <h2>5. User Conduct</h2>
          <p>Users agree to use the website and services for lawful purposes only and must not engage in any behavior that could damage or impair the website's functionality.</p>

          <h2>6. Payment Terms</h2>
          <p>Course fees must be paid in full before the start of any program. Refunds are subject to our refund policy and must be requested within specified timeframes.</p>

          <h2>7. Limitation of Liability</h2>
          <p>Sigma Cyber shall not be liable for any indirect, incidental, special, consequential, or punitive damages resulting from your use of our services.</p>

          <h2>8. Changes to Terms</h2>
          <p>We reserve the right to modify these terms at any time. Users will be notified of any changes through the website.</p>

          <h2>9. Governing Law</h2>
          <p>These terms shall be governed by and construed in accordance with the laws of the State of Alabama.</p>

          <h2>10. Contact Information</h2>
          <p>For questions about these Terms of Use, please contact us at:</p>
          <ul>
            <li>Email: legal@sigmacybercorp.com</li>
            <li>Phone: 205.415.9470</li>
            <li>Address: 710 7th Street Clanton, AL 35045</li>
          </ul>
        </div>
      </main>

      <Footer />
    </div>
  );
}