import React from 'react';
import { Link } from 'react-router-dom';
import { Users, BookOpen, GraduationCap, BarChart, Settings, ChevronRight, FileText } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';

const stats = [
  {
    name: 'Total Users',
    value: '156',
    change: '+12%',
    changeType: 'increase'
  },
  {
    name: 'Active Courses',
    value: '8',
    change: '+2',
    changeType: 'increase'
  },
  {
    name: 'Course Completion Rate',
    value: '78%',
    change: '+5%',
    changeType: 'increase'
  },
  {
    name: 'Average Progress',
    value: '64%',
    change: '+3%',
    changeType: 'increase'
  }
];

const quickActions = [
  {
    name: 'Manage Users',
    description: 'Add, edit, or remove users and their roles',
    icon: Users,
    to: '/admin/users'
  },
  {
    name: 'Manage Courses',
    description: 'Create and update course content',
    icon: BookOpen,
    to: '/admin/courses'
  },
  {
    name: 'Manage Content',
    description: 'Edit website content and images',
    icon: FileText,
    to: '/admin/content'
  },
  {
    name: 'View Reports',
    description: 'Access analytics and progress reports',
    icon: BarChart,
    to: '/admin/reports'
  },
  {
    name: 'System Settings',
    description: 'Configure system preferences',
    icon: Settings,
    to: '/admin/settings'
  }
];

export default function AdminDashboard() {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Header />
      <div className="h-32"></div>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Admin Dashboard</h1>
            <p className="mt-2 text-gray-600 dark:text-gray-300">Manage your training platform</p>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {stats.map((stat) => (
            <div key={stat.name} className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg">
              <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">{stat.name}</h3>
              <div className="mt-2 flex items-baseline">
                <p className="text-2xl font-semibold text-gray-900 dark:text-white">{stat.value}</p>
                <p className={`ml-2 flex items-baseline text-sm font-semibold ${
                  stat.changeType === 'increase' ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'
                }`}>
                  {stat.change}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Quick Actions Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {quickActions.map((action) => {
            const Icon = action.icon;
            return (
              <Link
                key={action.name}
                to={action.to}
                className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow"
              >
                <div className="flex items-center gap-4 mb-4">
                  <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-lg">
                    <Icon className="h-6 w-6 text-blue-600" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{action.name}</h3>
                </div>
                <p className="text-gray-600 dark:text-gray-300 mb-4">{action.description}</p>
                <div className="flex items-center text-blue-600 font-medium">
                  Manage
                  <ChevronRight className="h-4 w-4 ml-1" />
                </div>
              </Link>
            )
          })}
        </div>

        {/* Recent Activity */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
          <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6">Recent Activity</h2>
          <div className="space-y-6">
            <div className="flex items-start gap-4">
              <div className="p-2 bg-green-100 dark:bg-green-900 rounded-lg">
                <Users className="h-5 w-5 text-green-600" />
              </div>
              <div>
                <p className="text-gray-900 dark:text-white font-medium">New user registered</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">John Doe joined the platform</p>
                <p className="text-xs text-gray-400 dark:text-gray-500">2 hours ago</p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="p-2 bg-blue-100 dark:bg-blue-900 rounded-lg">
                <BookOpen className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <p className="text-gray-900 dark:text-white font-medium">Course updated</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">CCNA certification content updated</p>
                <p className="text-xs text-gray-400 dark:text-gray-500">5 hours ago</p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="p-2 bg-purple-100 dark:bg-purple-900 rounded-lg">
                <GraduationCap className="h-5 w-5 text-purple-600" />
              </div>
              <div>
                <p className="text-gray-900 dark:text-white font-medium">Course completed</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">Sarah Smith completed Security+</p>
                <p className="text-xs text-gray-400 dark:text-gray-500">1 day ago</p>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}