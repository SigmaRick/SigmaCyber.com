import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Brain, CheckCircle, Code, Terminal, Bot } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';

const courses = [
  {
    title: "AI Development Fundamentals",
    description: "Learn the basics of AI development with Bolt, including prompt engineering, system design, and best practices.",
    price: "$495",
    schedule: "Friday or Saturday, 9 AM - 5 PM",
    duration: "1 Day (8 Hours)",
    topics: [
      "Introduction to AI Development",
      "Understanding Prompt Engineering",
      "System Design with AI",
      "Best Practices and Patterns",
      "Building Basic AI Applications",
      "Integration with Web Applications"
    ]
  },
  {
    title: "Advanced AI Application Development",
    description: "Master advanced AI development techniques, complex system design, and enterprise integration patterns.",
    price: "$495",
    schedule: "Friday or Saturday, 9 AM - 5 PM",
    duration: "1 Day (8 Hours)",
    topics: [
      "Advanced Prompt Engineering",
      "Complex System Architecture",
      "AI Integration Patterns",
      "Performance Optimization",
      "Error Handling and Edge Cases",
      "Security Best Practices"
    ]
  },
  {
    title: "Enterprise AI Solutions",
    description: "Learn to build production-ready AI applications, focusing on scalability, security, and enterprise integration.",
    price: "$495",
    schedule: "Friday or Saturday, 9 AM - 5 PM",
    duration: "1 Day (8 Hours)",
    topics: [
      "Enterprise AI Architecture",
      "Scalability and Performance",
      "Security and Compliance",
      "Advanced Integration Patterns",
      "Monitoring and Analytics",
      "Deployment Strategies"
    ]
  }
];

function CourseCard({ course, onClick }: { course: typeof courses[0], onClick: () => void }) {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
      <div className="p-8">
        <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">{course.title}</h3>
        <p className="text-gray-600 dark:text-gray-300 mb-6">{course.description}</p>
        
        <div className="space-y-6 mb-8">
          <div className="space-y-4">
            <h4 className="font-semibold text-gray-900 dark:text-white">Key Topics</h4>
            <ul className="space-y-3">
              {course.topics.map((topic, index) => (
                <li key={index} className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                  <span className="ml-3 text-gray-600 dark:text-gray-300">{topic}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="space-y-3 pt-6 border-t border-gray-200 dark:border-gray-700">
            <div className="flex justify-between items-center">
              <span className="text-gray-600 dark:text-gray-300">Duration:</span>
              <span className="font-medium text-gray-900 dark:text-white">{course.duration}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600 dark:text-gray-300">Schedule:</span>
              <span className="font-medium text-gray-900 dark:text-white">{course.schedule}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600 dark:text-gray-300">Price:</span>
              <span className="text-2xl font-bold text-gray-900 dark:text-white">{course.price}</span>
            </div>
          </div>
        </div>

        <button
          onClick={onClick}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-6 rounded-lg transition-colors"
        >
          Learn More
        </button>
      </div>
    </div>
  );
}

export default function AITraining() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 pt-48 pb-16">
      <Header />
      <div className="h-32"></div>

      <main className="pb-16">
        {/* Hero Section */}
        <div className="relative overflow-hidden bg-gradient-to-r from-blue-600 to-blue-800 py-24 mb-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div className="text-center max-w-3xl mx-auto">
              <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
                Master AI Development with Bolt
              </h1>
              <p className="text-xl text-blue-100 mb-8">
                Learn to build powerful AI applications with hands-on training from industry experts
              </p>
              <div className="flex flex-wrap justify-center gap-4 text-sm">
                <div className="bg-white/10 text-white px-4 py-2 rounded-full">
                  One-Day Classes
                </div>
                <div className="bg-white/10 text-white px-4 py-2 rounded-full">
                  Hands-on Projects
                </div>
                <div className="bg-white/10 text-white px-4 py-2 rounded-full">
                  Expert Instructors
                </div>
                <div className="bg-white/10 text-white px-4 py-2 rounded-full">
                  Production-Ready Skills
                </div>
              </div>
            </div>
          </div>
          <div className="absolute inset-0 bg-gradient-to-b from-transparent to-gray-50 dark:to-gray-900" />
        </div>

        {/* Course Listings */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {courses.map((course, index) => {
              const paths = [
                '/ai-training/fundamentals',
                '/ai-training/advanced',
                '/ai-training/enterprise'
              ];
              return (
                <CourseCard 
                  key={index} 
                  course={course} 
                  onClick={() => navigate(paths[index])} 
                />
              );
            })}
          </div>

          {/* Why Choose Our AI Training */}
          <div className="mt-24">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white text-center mb-12">
              Why Choose Our AI Training?
            </h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              <div className="text-center">
                <div className="flex justify-center mb-4">
                  <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-lg">
                    <Brain className="h-6 w-6 text-blue-600" />
                  </div>
                </div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  Expert Instructors
                </h3>
                <p className="text-gray-600 dark:text-gray-300">
                  Learn from experienced AI developers and engineers
                </p>
              </div>

              <div className="text-center">
                <div className="flex justify-center mb-4">
                  <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-lg">
                    <Code className="h-6 w-6 text-blue-600" />
                  </div>
                </div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  Hands-on Projects
                </h3>
                <p className="text-gray-600 dark:text-gray-300">
                  Build real-world AI applications during the course
                </p>
              </div>

              <div className="text-center">
                <div className="flex justify-center mb-4">
                  <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-lg">
                    <Terminal className="h-6 w-6 text-blue-600" />
                  </div>
                </div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  Production-Ready Skills
                </h3>
                <p className="text-gray-600 dark:text-gray-300">
                  Learn best practices for building production AI systems
                </p>
              </div>

              <div className="text-center">
                <div className="flex justify-center mb-4">
                  <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-lg">
                    <Bot className="h-6 w-6 text-blue-600" />
                  </div>
                </div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  Latest AI Technology
                </h3>
                <p className="text-gray-600 dark:text-gray-300">
                  Stay current with the latest AI development tools
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}