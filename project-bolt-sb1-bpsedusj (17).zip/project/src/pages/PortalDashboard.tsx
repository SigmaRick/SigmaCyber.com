import React from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Clock, Award, CheckCircle, PlayCircle, FileText, BarChart, Calendar, Users } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';

const courses = [
  {
    id: 'ccna',
    name: 'Cisco CCNA',
    progress: 45,
    nextSession: 'Today, 2:00 PM',
    instructor: 'Rick Miller',
    description: 'Network fundamentals, security basics, and automation concepts'
  },
  {
    id: 'security-plus',
    name: 'CompTIA Security+',
    progress: 30,
    nextSession: 'Tomorrow, 10:00 AM',
    instructor: 'Rick Miller',
    description: 'Cybersecurity concepts and best practices'
  }
];

const upcomingEvents = [
  {
    title: 'CCNA Lab Session',
    date: 'Today, 2:00 PM',
    type: 'Lab'
  },
  {
    title: 'Security+ Practice Exam',
    date: 'Tomorrow, 10:00 AM',
    type: 'Exam'
  },
  {
    title: 'Q&A Session',
    date: 'Wed, 3:00 PM',
    type: 'Meeting'
  }
];

function ProgressBar({ progress }: { progress: number }) {
  return (
    <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
      <div
        className="bg-blue-600 h-2 rounded-full"
        style={{ width: `${progress}%` }}
      />
    </div>
  );
}

export default function PortalDashboard() {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Header />
      <div className="h-32"></div>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Welcome back, Demo User</h1>
          <p className="mt-2 text-gray-600 dark:text-gray-300">Track your progress and access your course materials</p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-lg">
                <BookOpen className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-300">Active Courses</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">2</p>
              </div>
            </div>
          </div>
          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-green-100 dark:bg-green-900 rounded-lg">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-300">Completed Modules</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">12</p>
              </div>
            </div>
          </div>
          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-purple-100 dark:bg-purple-900 rounded-lg">
                <Clock className="h-6 w-6 text-purple-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-300">Study Hours</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">24</p>
              </div>
            </div>
          </div>
          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-orange-100 dark:bg-orange-900 rounded-lg">
                <Award className="h-6 w-6 text-orange-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-300">Certifications</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">0</p>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Active Courses */}
          <div className="lg:col-span-2 space-y-6">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Active Courses</h2>
            {courses.map(course => (
              <div key={course.id} className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 dark:text-white">{course.name}</h3>
                    <p className="text-gray-600 dark:text-gray-300 text-sm mt-1">{course.description}</p>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-300">
                    <Users className="h-4 w-4" />
                    <span>{course.instructor}</span>
                  </div>
                </div>
                <div className="mb-4">
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-gray-600 dark:text-gray-300">Progress</span>
                    <span className="text-gray-900 dark:text-white font-medium">{course.progress}%</span>
                  </div>
                  <ProgressBar progress={course.progress} />
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-300">
                    <Calendar className="h-4 w-4" />
                    <span>Next session: {course.nextSession}</span>
                  </div>
                  <div className="flex gap-2">
                    <button className="px-4 py-2 bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors flex items-center gap-2">
                      <PlayCircle className="h-4 w-4" />
                      Resume
                    </button>
                    <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2">
                      <FileText className="h-4 w-4" />
                      Materials
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Upcoming Events */}
          <div>
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Upcoming Events</h2>
            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg">
              <div className="space-y-6">
                {upcomingEvents.map((event, index) => (
                  <div key={index} className="flex items-start gap-4">
                    <div className="p-2 bg-blue-100 dark:bg-blue-900 rounded-lg">
                      {event.type === 'Lab' && <BookOpen className="h-5 w-5 text-blue-600" />}
                      {event.type === 'Exam' && <BarChart className="h-5 w-5 text-blue-600" />}
                      {event.type === 'Meeting' && <Users className="h-5 w-5 text-blue-600" />}
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-900 dark:text-white">{event.title}</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-300">{event.date}</p>
                    </div>
                  </div>
                ))}
              </div>
              <button className="mt-6 w-full px-4 py-2 bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors">
                View Calendar
              </button>
            </div>

            {/* Quick Links */}
            <div className="mt-8 bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg">
              <h2 className="text-lg font-bold text-gray-900 dark:text-white mb-4">Quick Links</h2>
              <div className="space-y-3">
                <a href="#" className="block px-4 py-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                  Practice Exams
                </a>
                <a href="#" className="block px-4 py-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                  Study Resources
                </a>
                <a href="#" className="block px-4 py-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                  Virtual Labs
                </a>
                <a href="#" className="block px-4 py-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                  Support
                </a>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}