import React from 'react';
import { Link } from 'react-router-dom';
import { useEffect } from 'react';
import { Network, Code, CheckCircle, Server, Clock, Users, Laptop, Cloud, Lock, Database, Shield } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';

interface ServiceCardProps {
  title: string;
  description: string;
  to: string;
  features: string[];
  icon: React.ComponentType<{ className?: string }>;
}

function ServiceCard({ title, description, features, icon: Icon, to }: ServiceCardProps) {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl p-8 border border-gray-200 dark:border-gray-700">
      <div className="flex items-center gap-4 mb-6">
        <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-lg">
          <Icon className="h-8 w-8 text-blue-600" />
        </div>
        <h3 className="text-2xl font-bold text-gray-900 dark:text-white">{title}</h3>
      </div>
      <p className="text-gray-600 dark:text-gray-300 mb-6">{description}</p>
      <ul className="space-y-4 mb-8">
        {features.map((feature, index) => (
          <li key={index} className="flex items-start">
            <CheckCircle className="h-6 w-6 text-green-500 mt-1 flex-shrink-0" />
            <span className="ml-3 text-gray-600 dark:text-gray-300">{feature}</span>
          </li>
        ))}
      </ul>
      <div className="border-t border-gray-200 dark:border-gray-700 pt-6">
        <Link
          to={to}
          className="w-full bg-blue-600 text-white py-3 px-4 rounded-md hover:bg-blue-700 transition-colors inline-block text-center"
        >
          Get Started
        </Link>
      </div>
    </div>
  );
}

function ITSupport() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <Header />
      <div className="h-32"></div>

      <main className="pb-16">
        {/* Hero Section */}
        <div className="relative overflow-hidden bg-gradient-to-r from-blue-600 to-blue-800 py-24 mb-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div className="text-center max-w-3xl mx-auto">
              <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
                Enterprise IT Support Solutions
              </h1>
              <p className="text-xl text-blue-100 mb-8">
                Comprehensive IT support services tailored to your business needs. From network infrastructure to cybersecurity, we've got you covered.
              </p>
            </div>
          </div>
          <div className="absolute inset-0 bg-gradient-to-b from-transparent to-gray-50 dark:to-gray-900" />
        </div>

        {/* Image Section */}
        <div className="relative h-[500px] overflow-hidden">
          <img
            src="https://images.unsplash.com/photo-1588508065123-287b28e013da?auto=format&fit=crop&q=80"
            alt="Network engineer working in modern data center"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-blue-900/80 to-transparent">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center">
              <div className="max-w-xl">
                <h2 className="text-3xl font-bold text-white mb-4">Expert Network Infrastructure Management</h2>
                <p className="text-xl text-blue-100">Our certified engineers ensure your network infrastructure runs at peak performance 24/7</p>
              </div>
            </div>
          </div>
        </div>

        {/* Services Grid */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <ServiceCard
              to="/services/network-infrastructure"
              title="Network Infrastructure"
              description="Complete network management and optimization services"
              icon={Network}
              features={[
                "24/7 network monitoring",
                "Infrastructure design and implementation",
                "Performance optimization",
                "Network security management",
                "Bandwidth optimization"
              ]}
            />

            <ServiceCard
              title="Managed IT Services"
              description="Comprehensive IT management and support"
              to="/services/managed-services"
              icon={Server}
              features={[
                "24/7 help desk support",
                "System administration",
                "Hardware maintenance",
                "Software updates and patches",
                "Regular system audits"
              ]}
            />

            <ServiceCard
              title="Cloud Services"
              description="Cloud infrastructure management and optimization"
              to="/services/cloud-services"
              icon={Cloud}
              features={[
                "Cloud migration services",
                "AWS/Azure management",
                "Cloud security",
                "Performance monitoring",
                "Cost optimization"
              ]}
            />

            <ServiceCard
              title="Cybersecurity"
              description="Advanced security solutions and monitoring"
              to="/services/enterprise-cybersecurity"
              icon={Lock}
              features={[
                "Threat detection and response",
                "Security assessments",
                "Firewall management",
                "Employee security training",
                "Incident response planning"
              ]}
            />

            <ServiceCard
              title="Data Management"
              description="Comprehensive data solutions and backup services"
              to="/services/data-management"
              icon={Database}
              features={[
                "Backup and recovery",
                "Data migration",
                "Database management",
                "Data security",
                "Compliance management"
              ]}
            />

            <ServiceCard
              title="End-User Support"
              description="Desktop and user support services"
              to="/services/end-user-support"
              icon={Users}
              features={[
                "Hardware support",
                "Software troubleshooting",
                "User training",
                "Device management",
                "Remote support"
              ]}
            />
          </div>
        </div>

        {/* Why Choose Us Section */}
        <div className="bg-white dark:bg-gray-800 py-24">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl font-bold text-center text-gray-900 dark:text-white mb-16">
              Why Choose Our IT Support Services?
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              <div className="text-center">
                <div className="flex justify-center mb-4">
                  <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-lg">
                    <Clock className="h-8 w-8 text-blue-600" />
                  </div>
                </div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">24/7 Support</h3>
                <p className="text-gray-600 dark:text-gray-300">Round-the-clock monitoring and support for your systems</p>
              </div>
              <div className="text-center">
                <div className="flex justify-center mb-4">
                  <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-lg">
                    <Users className="h-8 w-8 text-blue-600" />
                  </div>
                </div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Expert Team</h3>
                <p className="text-gray-600 dark:text-gray-300">Certified professionals with years of industry experience</p>
              </div>
              <div className="text-center">
                <div className="flex justify-center mb-4">
                  <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-lg">
                    <Laptop className="h-8 w-8 text-blue-600" />
                  </div>
                </div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Custom Solutions</h3>
                <p className="text-gray-600 dark:text-gray-300">Tailored IT solutions to meet your specific needs</p>
              </div>
              <div className="text-center">
                <div className="flex justify-center mb-4">
                  <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-lg">
                    <Shield className="h-8 w-8 text-blue-600" />
                  </div>
                </div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Security First</h3>
                <p className="text-gray-600 dark:text-gray-300">Advanced security measures to protect your business</p>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <Footer />
    </div>
  );
}

export default ITSupport;