import React from 'react';
import { Link } from 'react-router-dom';
import { Phone, Sun, Moon } from 'lucide-react';
import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../utils/supabase';

function Logo({ className = '', showTagline = true }: { className?: string, showTagline?: boolean }) {
  const logoUrl = 'https://wkddnyxqlsewacuexjyi.supabase.co/storage/v1/object/public/images//FullLogo.jpg';

  return (
    <div className={`flex flex-col ${className}`}>
      <div className="h-32 md:h-64 flex items-center">
        <img 
          src={logoUrl} 
          alt="Sigma Cyber" 
          className="h-64 md:h-[28rem] w-auto object-contain md:-mt-32 md:-ml-48"
        />
      </div>
    </div>
  );
}

function DarkModeToggle() {
  const [isDark, setIsDark] = useState(false);

  useEffect(() => {
    if (localStorage.theme === 'dark' || (!localStorage.theme && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
      setIsDark(true);
      document.documentElement.classList.add('dark');
    }
  }, []);

  const toggleDarkMode = () => {
    if (isDark) {
      document.documentElement.classList.remove('dark');
      localStorage.theme = 'light';
    } else {
      document.documentElement.classList.add('dark');
      localStorage.theme = 'dark';
    }
    setIsDark(!isDark);
  };

  return (
    <button
      onClick={toggleDarkMode}
      className="p-2 rounded-lg bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-white hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors"
      aria-label="Toggle dark mode"
    >
      {isDark ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
    </button>
  );
}

export default function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const closeMobileMenu = useCallback(() => {
    setIsMobileMenuOpen(false);
  }, []);

  useEffect(() => {
    if (isMobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isMobileMenuOpen]);

  return (
    <header className="bg-gradient-to-b from-gray-900/80 dark:from-black/80 to-transparent absolute top-0 left-0 right-0 z-40 transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          <Link to="/" className="hover:opacity-80 transition-opacity">
            <Logo className="scale-50 md:scale-75" showTagline={false} />
          </Link>
          <div className="hidden md:flex items-center gap-8">
            <nav className="hidden md:block">
              <ul className="flex items-center gap-4 lg:gap-6">
                <li>
                  <Link to="/services/enterprise-cybersecurity" className="text-white hover:text-blue-200 transition-colors">
                    Enterprise Cybersecurity
                  </Link>
                </li>
                <li>
                  <Link to="/sigma-ai" className="text-white hover:text-blue-200 transition-colors">
                    Sigma AI
                  </Link>
                </li>
                <li>
                  <Link to="/ai-training" className="text-white hover:text-blue-200 transition-colors">
                    AI Training
                  </Link>
                </li>
                <li>
                  <Link to="/certification-training" className="text-white hover:text-blue-200 transition-colors">
                    Certification Training
                  </Link>
                </li>
                <li>
                  <Link to="/it-support" className="text-white hover:text-blue-200 transition-colors">
                    IT Support
                  </Link>
                </li>
              </ul>
            </nav>
            <div className="flex items-center gap-4">
              <a 
                href="tel:205.415.9470"
                className="hidden md:flex items-center gap-2 text-white hover:text-blue-200 transition-colors"
              >
                <Phone className="h-5 w-5" />
                <span>205.415.9470</span>
              </a>
              <DarkModeToggle />
            </div>
          </div>
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="md:hidden p-2 text-white hover:text-blue-200 transition-colors"
            aria-label="Toggle menu"
          >
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
          <div className={`fixed inset-0 bg-gray-900/95 z-50 md:hidden transition-transform ${isMobileMenuOpen ? 'translate-x-0' : 'translate-x-full'}`}>
            <div className="flex flex-col h-full p-6">
              <div className="flex justify-end mb-8">
                <button
                  onClick={closeMobileMenu}
                  className="p-2 text-white hover:text-blue-200 transition-colors"
                  aria-label="Close menu"
                >
                  <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
              <nav className="flex-1">
                <ul className="space-y-6">
                  <li>
                    <Link 
                      to="/services/enterprise-cybersecurity" 
                      className="text-xl font-medium text-white hover:text-blue-200 transition-colors block"
                      onClick={closeMobileMenu}
                    >
                      Enterprise Cybersecurity
                    </Link>
                  </li>
                  <li>
                    <Link 
                      to="/sigma-ai" 
                      className="text-xl font-medium text-white hover:text-blue-200 transition-colors block"
                      onClick={closeMobileMenu}
                    >
                      Sigma AI
                    </Link>
                  </li>
                  <li>
                    <Link 
                      to="/ai-training" 
                      className="text-xl font-medium text-white hover:text-blue-200 transition-colors block"
                      onClick={closeMobileMenu}
                    >
                      AI Training
                    </Link>
                  </li>
                  <li>
                    <Link 
                      to="/certification-training" 
                      className="text-xl font-medium text-white hover:text-blue-200 transition-colors block"
                      onClick={closeMobileMenu}
                    >
                      Certification Training
                    </Link>
                  </li>
                  <li>
                    <Link 
                      to="/it-support" 
                      className="text-xl font-medium text-white hover:text-blue-200 transition-colors block"
                      onClick={closeMobileMenu}
                    >
                      IT Support
                    </Link>
                  </li>
                </ul>
              </nav>
              <div className="pt-6 border-t border-white/10">
                <a
                  href="tel:205.415.9470"
                  className="flex items-center gap-3 text-white hover:text-blue-200 transition-colors text-lg"
                >
                  <Phone className="h-5 w-5" />
                  <span>205.415.9470</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}