import React, { useState } from 'react';
import { sendEmail } from '../utils/email';

interface ContactFormProps {
  className?: string;
  onSuccess?: () => void;
  onError?: (error: Error) => void;
}

export default function ContactForm({ className, onSuccess, onError }: ContactFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [status, setStatus] = useState<'idle' | 'success' | 'error'>('idle');

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);

    const formData = new FormData(e.currentTarget);
    const data = {
      from_name: formData.get('name'),
      from_email: formData.get('from_email'),
      phone: formData.get('phone'),
      company: formData.get('company'),
      inquiry_type: formData.get('inquiry-type'),
      message: `
Inquiry Type: ${formData.get('inquiry-type')}
Name: ${formData.get('name')}
Email: ${formData.get('email')}
Phone: ${formData.get('phone')}
Company: ${formData.get('company')}

Message:
${formData.get('message')}
      `.trim()
    };

    try {
      const response = await sendEmail(data, "template_urxs95c");
      setStatus('success');
      onSuccess?.();
      if (e.currentTarget) {
        e.currentTarget.reset();
      }
    } catch (error) {
      onError?.(error as Error);
      console.error('Error sending email:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form className={`space-y-6 ${className}`} onSubmit={handleSubmit}>
      <div>
        <label htmlFor="inquiry-type" className="block text-sm font-medium text-gray-700 dark:text-gray-200">
          Inquiry Type
        </label>
        <select
          id="inquiry-type"
          name="inquiry-type"
          required
          className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 bg-white dark:bg-gray-600 text-gray-900 dark:text-white"
        >
          <option value="training">Certification Training</option>
          <option value="ai-solutions">AI Solutions</option>
          <option value="ai-training">AI Training</option>
          <option value="enterprise-security">Enterprise Security</option>
          <option value="support">IT Support Services</option>
        </select>
      </div>
      <div>
        <label htmlFor="phone" className="block text-sm font-medium text-gray-700 dark:text-gray-200">
          Phone
        </label>
        <input
          type="tel"
          name="phone"
          id="phone"
          required
          className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 bg-white dark:bg-gray-600 text-gray-900 dark:text-white"
        />
      </div>
      <div>
        <label htmlFor="company" className="block text-sm font-medium text-gray-700 dark:text-gray-200">
          Company (Optional)
        </label>
        <input
          type="text"
          name="company"
          id="company"
          className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 bg-white dark:bg-gray-600 text-gray-900 dark:text-white"
        />
      </div>
      <div>
        <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-200">
          Name
        </label>
        <input
          type="text"
          name="name"
          id="name"
          required
          className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 bg-white dark:bg-gray-600 text-gray-900 dark:text-white"
        />
      </div>
      <div>
        <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-200">
          Email
        </label>
        <input
          type="email"
          name="from_email"
          id="email"
          required
          className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 bg-white dark:bg-gray-600 text-gray-900 dark:text-white"
        />
      </div>
      <div>
        <label htmlFor="message" className="block text-sm font-medium text-gray-700 dark:text-gray-200">
          Message
        </label>
        <textarea
          name="message"
          id="message"
          rows={4}
          required
          className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 bg-white dark:bg-gray-600 text-gray-900 dark:text-white"
        />
      </div>

      {status === 'success' && (
        <div className="p-4 bg-green-50 dark:bg-green-900/30 text-green-800 dark:text-green-200 rounded-md">
          Message sent successfully! We'll get back to you soon.
        </div>
      )}

      <button
        type="submit"
        disabled={isSubmitting}
        className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {isSubmitting ? 'Sending...' : 'Send Message'}
      </button>
    </form>
  );
}