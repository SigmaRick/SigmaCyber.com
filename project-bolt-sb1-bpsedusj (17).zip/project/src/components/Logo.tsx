import React from 'react';

interface LogoProps {
  className?: string;
  showTagline?: boolean;
}

export default function Logo({ className = '', showTagline = true }: LogoProps) {
  return (
    <div className={`flex flex-col items-center ${className}`}>
      <div className="relative">
        <div className="flex items-center gap-2">
          <div className="relative">
            <Hexagon className="h-10 w-10 text-blue-600" />
            <Shield className="h-6 w-6 text-white absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2" />
          </div>
          <span className="text-2xl font-bold text-white">Sigma Cyber</span>
        </div>
      </div>
      {showTagline && (
        <p className="text-blue-400 tracking-wider mt-2 text-sm">
          Expert Security Training & IT Support
        </p>
      )}
    </div>
  );
}