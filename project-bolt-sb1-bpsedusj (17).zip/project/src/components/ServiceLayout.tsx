import React from 'react';
import Header from './Header';
import Footer from './Footer';

interface ServiceLayoutProps {
  children: React.ReactNode;
  title: string;
  description: string;
  image: string;
  icon: React.ComponentType<{ className?: string }>;
}

export default function ServiceLayout({ children, title, description, image, icon: Icon }: ServiceLayoutProps) {
  return (
    <div className="min-h-screen bg-white dark:bg-gray-900">
      <Header />
      <div className="h-32"></div>
      <div className="relative h-[400px] overflow-hidden">
        <img
          src={image}
          alt={title}
          className="w-full h-full object-cover brightness-75"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-blue-900/80 to-transparent flex items-center">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center">
            <div className="max-w-2xl">
              <div className="flex items-center gap-4 mb-4">
                <div className="p-3 bg-white/10 rounded-lg">
                  <Icon className="h-8 w-8 text-white" />
                </div>
                <h1 className="text-4xl font-bold text-white">{title}</h1>
              </div>
              <p className="text-xl text-blue-100 max-w-xl">{description}</p>
            </div>
          </div>
        </div>
      </div>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {children}
      </main>

      <Footer />
    </div>
  );
}