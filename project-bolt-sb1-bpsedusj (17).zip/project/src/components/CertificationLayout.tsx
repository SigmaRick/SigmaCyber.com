import React from 'react';
import { useEffect } from 'react';
import Header from './Header';
import Footer from './Footer';

interface CertificationLayoutProps {
  children: React.ReactNode;
  title: string;
  description: string;
  image: string;
}

export default function CertificationLayout({ children, title, description, image }: CertificationLayoutProps) {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900">
      <Header />
      <div className="h-32"></div>
      <div className="relative h-[400px] overflow-hidden">
        <img
          src={image}
          alt={title}
          className="w-full h-full object-cover brightness-75"
        />
        <div className="absolute inset-0 bg-black/50 flex items-center">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center">
            <div className="max-w-2xl">
              <h1 className="text-4xl font-bold text-white mb-4">{title}</h1>
              <p className="text-xl text-white max-w-xl">{description}</p>
            </div>
          </div>
        </div>
      </div>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {children}
      </main>

      <Footer />
    </div>
  );
}