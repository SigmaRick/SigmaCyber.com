import emailjs from '@emailjs/browser';

// Initialize with public key
emailjs.init("G4Tkw7atwNefbdPkz");

export const sendEmail = async (templateParams: Record<string, unknown>, templateId: string) => {
  try {
    const response = await emailjs.send(
      "service_cmdqxlo", // Service ID
      templateId,
      {
        ...templateParams,
        _template: templateId,
        _service: "service_cmdqxlo",
      },
      "G4Tkw7atwNefbdPkz" // Public key
    );
    
    if (response.status !== 200) {
      throw new Error('Failed to send email');
    }
    
    return response;
  } catch (error) {
    console.error("Error sending email:", error);
    throw error;
  }
};